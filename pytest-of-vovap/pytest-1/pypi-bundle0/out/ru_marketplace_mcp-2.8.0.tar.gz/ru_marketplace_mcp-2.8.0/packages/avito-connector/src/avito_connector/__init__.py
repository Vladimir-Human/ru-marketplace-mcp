"""Avito MCP connector."""

__version__ = "2.8.0"
