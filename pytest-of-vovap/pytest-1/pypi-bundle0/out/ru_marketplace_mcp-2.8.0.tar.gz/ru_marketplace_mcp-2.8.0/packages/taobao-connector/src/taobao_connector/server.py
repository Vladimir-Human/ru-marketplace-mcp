"""Taobao MCP connector.

Taobao's search is a client-side React app whose data layer is the signed mtop
API: every XHR wants a ``sign`` parameter computed from the ``_m_h5_tk`` cookie
token, and anonymous probes answer ``FAIL_SYS_TOKEN_EMPTY``. There is no
anonymous JSON route worth maintaining — but there is also no captcha wall: the
pages themselves answer 200 from a datacenter IP. So every read here runs in
the operator's own Chrome over CDP, where the site's own JS signs requests
natively, and the connector reads the rendered DOM plus in-page state.

Verified live July 2026 from a datacenter IP (docs/ANTI_BOT.md):
  - ``s.taobao.com/search?q=…`` — 200, ~33 KB shell, results load over mtop XHR
  - ``h5api.m.taobao.com`` unsigned — ``FAIL_SYS_TOKEN_EMPTY``
  - main page, 1688, AliExpress — 200, no IP-level block

Since 2026-09-10 a LOGGED-OUT session on ``s.taobao.com/search`` no longer gets
the results shell: it is served a login wall with an EMPTY document title, zero
item.taobao.com anchors and /member/login.jhtml + /member/new_register.jhtml
routes. The same-day live diagnose measured readyState interactive, a ~39 KB
body and 33 links; the committed TRIMMED capture
(tests/fixtures/search_login_wall_live.html) measures 29.5 KB and 32 anchors,
and readyState/body size cannot be read back from a static file at all. A
title-only wall check cannot see that variant, so wall detection is structural
as well as titular (``_login_wall_markers``): tools answer ``transport_down``
with the log-in fix inline and the selfcheck answers
``inconclusive(login_wall)``, never drift.

Prices stay in yuan (CNY). An agent comparing against ruble sources must
convert explicitly — a baked-in rate would go silently stale.

Search covers Taobao AND Tmall listings (owner decision, 2026-10-30): Tmall
tiles are ordinary products, often the official brand stores, and leaving them
out skews price comparisons. The ad-click trackers (``click.simba.taobao.com``)
stay OUT on purpose — visiting one bills the advertiser, and it is not a product
URL. ``taobao_card`` still speaks Taobao only: a Tmall card redirects to
``detail.tmall.com``, which the card's host policy refuses, so the tool says so
plainly instead of failing with a raw navigation error.

A search grid that is still rendering («加载中») is not an empty catalog. The
extractor transports that as a structural flag, the browser read re-checks the
same page for a bounded while, and a grid that never finishes is a retryable
timeout — never "parser drift".

NEVER write to stdout in a stdio MCP server — it corrupts JSON-RPC. Use
``log_event`` (stderr) or the ``Context`` logging methods.
"""
# START_MODULE_CONTRACT
# PURPOSE: Expose Taobao/Tmall search and Taobao-only item cards with prices kept in CNY.
# SCOPE: Read-only DOM/state; no ad-click trackers; bounded loading polls; explicit Tmall card refusal; challenge handoffs.
# DEPENDS: FastMCP; mcp_core DOM/CDP/handoff/cache/kit; models_output; settings; shape_reference.
# LINKS: M-TAOBAO; M-KIT; M-COMPARE; M-MARKETPLACE; R-TAOBAO-QUERY; R-TAOBAO-TMALL-SEARCH; R-TAOBAO-TMALL-CARD; R-TAOBAO-GRID-LOADING.
# END_MODULE_CONTRACT
# START_MODULE_MAP
# _search_url: Build canonical percent-encoded search/cache/handoff URLs.
# _is_tmall_url: Recognize the exact unsupported card host without accepting its item id.
# _extract_item_id: Validate item identifiers before constructing browser URLs.
# _search_item_from_tile: Normalize rendered Taobao/Tmall tiles without currency conversion.
# _cdp_render: Serialize paced browser reads, bound empty-grid polling and support challenge recovery.
# _login_wall_markers: Detect title-less login walls from structural signals.
# _grid_still_loading: An empty search page still rendering its grid, never a page offering login routes.
# _anti_bot_challenge: Read challenge evidence; ignore hidden card widget text.
# _page_challenge_kind: Classify handoffs from challenge evidence, not card fields.
# taobao_search: Read rendered Taobao/Tmall tiles, preserve missing prices, time out a loading grid; warn when a required key family vanishes.
# taobao_card: Refuse Tmall cards clearly; reject challenge evidence before item mapping and success caching.
# taobao_selfcheck: Diagnose operator browser/parser health; not an MCP tool.
# END_MODULE_MAP

from __future__ import annotations

import asyncio
import datetime
import json
import re
import urllib.parse
from typing import Annotated, Any

from fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from mcp_core import resilience as R
from mcp_core.cache import TTLCache
from mcp_core.dom import JS_HELPERS, prices_from_tile
from mcp_core.errors import (
    BadRequestError,
    ChallengeRequiredError,
    NotFoundError,
    ParserDriftError,
    ToolError,
    TransportDownError,
    UpstreamTimeoutError,
    raise_tool_error,
)
from mcp_core.kit import polite_wait
from mcp_core.logging import log_event
from mcp_core.output_schema import apply_compact_output_schemas
from mcp_core.pacing import Pacer
from mcp_core.redact import redact_error_text as _redact
from mcp_core.resources import register_reference_resources
from mcp_core.runtime import browser_handoff_lifespan, current_client_scope
from mcp_core.transport.browser_handoff import get_handoff_id, has_pending_handoff, read_with_handoff
from mcp_core.transport.chrome_cdp import NavBlocked, NavigationPolicyError, open_page
from pydantic import Field

from taobao_connector.models_output import (
    MetaOut,
    TaobaoCardResponse,
    TaobaoSearchItemOut,
    TaobaoSearchResponse,
    TaobaoSelfcheckResponse,
)
from taobao_connector.settings import get_settings
from taobao_connector.shape_reference import (
    SEARCH_REQUIRED_FAMILIES,
    SEARCH_SHAPE_REFERENCE,
    missing_required_families,
)

# START_BLOCK_CONFIG_AND_INPUTS
_settings = get_settings()

SERVER_VERSION = "2.8.0"
SERVER_STARTED_AT = datetime.datetime.now(datetime.UTC).isoformat().replace("+00:00", "Z")

SEARCH_BASE = "https://s.taobao.com/search"
ITEM_BASE = "https://item.taobao.com/item.htm"
_TMALL_CARD_MESSAGE = (
    "Tmall listings are not readable by taobao_card. The search result already carries title, price, shop and URL."
)

TIMEOUT = _settings.timeout
MAX_BODY_BYTES = _settings.max_body_bytes
_min_gap = _settings.min_gap
# Additional render time only; no new navigation and no waiting on login/CAPTCHA walls.
_GRID_POLL_INTERVAL_S = 1.5
_GRID_LOADING_TIMEOUT_S = 10.0

# Item ids are 11-12 digit strings; keep them as strings (they exceed the
# JS-safe integer range, and the page itself treats them as strings).
_ITEM_ID_RE = re.compile(r"[?&]id=(\d{9,13})\b")

mcp = FastMCP(
    name="taobao-connector",
    lifespan=browser_handoff_lifespan,
    version=SERVER_VERSION,
    instructions=(
        "Taobao and Tmall search listings, Taobao item cards, prices in yuan (CNY). Every "
        "read runs in the operator's own Chrome over CDP — Taobao's data API is "
        "signed per session, so there is no anonymous tier. Start with "
        "taobao_search; taobao_card takes a Taobao item id or URL and refuses Tmall cards. "
        "Tmall search results already carry title, price, shop and URL. "
        "Every tool's full field list and error codes are MCP resources (`guide://<source>/<tool>`); all error codes together are `marketplace://errors`."
    ),
)

_cache: TTLCache = TTLCache(ttl_s=_settings.cache_ttl, max_entries=128)
_pacer = Pacer(_min_gap)
_cdp_lock = asyncio.Lock()


async def _polite_wait() -> None:
    """Space this source's requests out, and back off if it refused us.

    Reads ``_min_gap`` at call time so an operator or a test can retune the
    pace without rebuilding the pacer. The pacing itself is shared
    (mcp_core.kit.polite_wait); this module-level name stays because the tools
    call it and the tests patch it.
    """
    await polite_wait(_pacer, _min_gap)


def _search_url(query: str, page: int = 1) -> str:
    """R-TAOBAO-QUERY: one canonical URL for navigation, cache and handoff keys.

    A space is encoded as ``%20``, not ``+``: Taobao read ``q=iphone+15`` as
    the literal text "iphone+15" (owner capture 2026-10-30), while the page's
    own search box held "iphone 15" for ``q=iphone%2015``. ``quote_via=quote``
    keeps a literal plus in the query as ``%2B`` — query data, not a space.
    This URL is also the cache key and the browser-handoff key, so it is built
    in ONE place and never re-encoded per call site.
    """
    params = urllib.parse.urlencode({"q": query.strip(), "page": str(page)}, quote_via=urllib.parse.quote)
    return f"{SEARCH_BASE}?{params}"


def _is_tmall_url(raw: str) -> bool:
    """Recognize only the exact unsupported card host; never accept its id for navigation."""
    parts = urllib.parse.urlsplit(raw.strip())
    return parts.scheme in ("", "http", "https") and (parts.hostname or "").rstrip(".").lower() == "detail.tmall.com"


def _extract_item_id(raw: str) -> str | None:
    """Pull the item id out of an item.taobao.com URL or a bare numeric id.

    Host-checked on purpose. The id is the only thing that survives this
    function, and the card URL is rebuilt from ITEM_BASE, so a caller cannot
    smuggle ``?id=`` into a path on someone else's domain and steer the
    operator's logged-in Chrome there. Anything that is not taobao.com, or
    carries a scheme we do not navigate, returns None.
    """
    raw = raw.strip()
    if raw.isdigit() and 9 <= len(raw) <= 13:
        return raw
    parts = urllib.parse.urlsplit(raw)
    if parts.scheme:
        if parts.scheme not in ("http", "https"):
            return None
        host = (parts.hostname or "").rstrip(".").lower()
        if host != "taobao.com" and not host.endswith(".taobao.com"):
            return None
    elif raw.startswith("//"):
        # Scheme-relative: the authority belongs to someone else, so the host
        # check above never runs and an off-host URL would yield an id instead
        # of a refusal. The card only ever navigates ITEM_BASE, so nothing
        # leaks — but silently reading an id out of a stranger's URL is not a
        # contract worth keeping.
        return None
    match = _ITEM_ID_RE.search(raw)
    if match:
        return match.group(1)
    return None


# END_BLOCK_CONFIG_AND_INPUTS

# START_BLOCK_DOM_EXTRACTION
# In-page extractor: walks the rendered Taobao/Tmall search DOM and returns plain data.
# Kept defensive — every panel is optional, because Taobao A/B tests layout
# variants constantly and a missing shop block must not kill the item.
# The shared helpers replace the per-connector heuristics that produced the
# July-2026 class of bugs elsewhere (closest() resolving to an empty overlay,
# Math.min picking the instalment, innerText absent in jsdom). Taobao tiles get
# the same treatment: the extractor returns raw display text, and the price is
# decided in Python by mcp_core.dom.prices_from_tile from glyph-attached
# candidates — so a yuan-glued "999¥" is a price and a bare promo number is not.
_SEARCH_EXTRACT_TEMPLATE = """
() => {
    //__SHARED_HELPERS__
    const ID_RE = /[?&]id=(\\d{9,13})/;
    const out = [];
    // Taobao AND Tmall products: a Tmall listing is an ordinary product
    // (often the official brand store) and skipping it skewed price
    // comparisons — owner decision 2026-10-30.
    const PRODUCT_ANCHORS = 'a[href*="item.taobao.com/item.htm"], a[href*="detail.tmall.com/item.htm"]';
    const anchors = document.querySelectorAll(PRODUCT_ANCHORS);
    const seen = new Set();
    for (const a of anchors) {
        let productUrl;
        try { productUrl = new URL(a.href); } catch (_) { continue; }
        // Direct product hosts only. click.simba.taobao.com ad-click trackers
        // are deliberately excluded: following them bills the advertiser.
        // Check the real host too, not a product URL embedded in a tracker query.
        if (!['http:', 'https:'].includes(productUrl.protocol)
            || !['item.taobao.com', 'detail.tmall.com'].includes(productUrl.hostname)
            || productUrl.pathname !== '/item.htm') continue;
        const m = productUrl.search.match(ID_RE);
        if (!m || seen.has(m[1])) continue;
        seen.add(m[1]);
        // tileRootFor, not closest(): an anchor whose own class looks like a
        // card must not become the tile. See mcp_core.dom.
        const card = tileRootFor(a, ID_RE) || a;
        // A dedicated title node carries the clean name. The tile anchor wraps
        // the WHOLE tile, and reading its text first glues the price, sales
        // and shop into the title (live capture 2026-08-07,
        // tests/fixtures/search_grid_live.html); anchor text is the fallback.
        let title = null;
        const titleNode = card.querySelector('[class*="title"], [class*="Title"]');
        if (titleNode) {
            title = cleanText(titleNode) || (titleNode.getAttribute('title') || null);
        }
        if (!title) {
            let titleEl = null;
            for (const cand of card.querySelectorAll(PRODUCT_ANCHORS + ', [class*="title"], [class*="Title"]')) {
                if (cleanText(cand)) { titleEl = cand; break; }
            }
            title = (titleEl ? cleanText(titleEl) : null) || (a.getAttribute('title') || null);
        }

        // Price: the modern layout splits it into unit (¥) + priceInt +
        // priceFloat nodes. The whole price block as one text blob glues the
        // sales count ("200+人付款") onto the digits, which coerce_price
        // rejects as ambiguous — every priced tile would read as no price.
        // Reassemble the display parts; Python's coerce_price still does the
        // parsing. Without a priceInt node, fall back to the shared glyph hunt
        // (the older layout renders one glyph-attached price node).
        const priceRoot = card.querySelector('[class*="priceWrapper"], [class*="PriceWrapper"]') || card;
        let price_texts = priceTextsIn(priceRoot);
        const intEl = priceRoot.querySelector('[class*="priceInt"]');
        if (intEl) {
            const intPart = cleanText(intEl);
            if (intPart) {
                const unitEl = priceRoot.querySelector('[class*="unit"]');
                const floatEl = priceRoot.querySelector('[class*="priceFloat"]');
                const unit = unitEl && cleanText(unitEl) ? cleanText(unitEl) : '';
                const floatPart = floatEl && cleanText(floatEl) ? cleanText(floatEl) : '';
                price_texts = {
                    attached: [unit + intPart + floatPart].concat(price_texts.attached),
                    other: price_texts.other
                };
            }
        }

        // Shop / sales / location from their scoped nodes first. The legacy
        // line scan below stays as the fallback, but it splits on newlines and
        // the live rendered tile text carries none, so on the modern layout it
        // only produces glued blobs.
        let shop = null, location = null, sales = null;
        const shopEl = card.querySelector('[class*="shopNameText"], [class*="Shop--shop"], [class*="shop--"]');
        if (shopEl) shop = cleanText(shopEl);
        const salesEl = card.querySelector('[class*="realSales"], [class*="sales"]');
        if (salesEl) sales = cleanText(salesEl);
        const procityEls = card.querySelectorAll('[class*="procity"]');
        if (procityEls.length) {
            const parts = [];
            for (const p of procityEls) {
                const t = cleanText(p);
                if (t) parts.push(t);
            }
            if (parts.length) location = parts.join(' ');
        }
        if (!shop || !sales || !location) {
            const lines = (card.textContent || '').split('\\n').map(s => s.trim()).filter(Boolean);
            for (const line of lines) {
                if (!sales && /人付款|人收货|已售|约售|付款$/.test(line)) sales = line;
                else if (!shop && /店$/.test(line)) shop = line;
                else if (!location && /发货地|广东|浙江|江苏|上海|北京/.test(line)) location = line;
            }
        }
        out.push({
            item_id: m[1],
            title: title,
            price_texts: price_texts,
            shop_name: shop,
            location: location,
            sales: sales,
            url: 'https://' + productUrl.hostname + '/item.htm?id=' + m[1]
        });
        if (out.length >= 48) break;
    }
    // Structural login-wall / anti-bot fields. The 2026-09-10 wall variant
    // serves an EMPTY document title
    // (tests/fixtures/search_login_wall_live.html), so the title check alone
    // cannot see it. Transport ONLY: the raw document title, raw anchor counts
    // and a bounded snippet of the VISIBLE body text (scripts/styles removed
    // via cleanTextWithout, so inline JS strings cannot fake a marker). Every
    // VERDICT is Python's: _login_wall_markers decides the login wall and
    // _anti_bot_challenge the captcha, both from these fields. The JS used to
    // bake title='__BLOCKED__' when challenge words matched
    // document.body.textContent INCLUDING hidden script/widget text — healthy
    // logged-out pages rendering 29-38 items were convicted by the hidden
    // baxia widget's «人机» (live probe 2026-09-10) and the shape-drift canary
    // never ran; the Python verdict gates the wording on zero extracted items.
    const wallText = cleanTextWithout(document.body, ['script', 'style']) || '';
    return JSON.stringify({
        items: out,
        title: document.title || '',
        anchors_total: document.querySelectorAll('a[href]').length,
        login_anchors: document.querySelectorAll('a[href*="login.jhtml"], a[href*="register.jhtml"]').length,
        // Structural text evidence only, before truncation; Python decides whether to wait.
        grid_loading: wallText.includes('加载中'),
        body_snippet: wallText.slice(0, 2000)
    });
}
"""

# Spliced like every other CDP source: one fix to tile resolution or price
# selection lands on all four connectors at once.
_SEARCH_EXTRACT_JS = _SEARCH_EXTRACT_TEMPLATE.replace("//__SHARED_HELPERS__", JS_HELPERS)


_CARD_EXTRACT_TEMPLATE = """
() => {
    //__SHARED_HELPERS__
    // The modern card renders the product name in a mainTitle span (with the
    // same text in its title attribute); there is no h1. The generic
    // [class*="title"] fallback is last on purpose: first in document order it
    // matches the header's image-search widget and reads its placeholder —
    // that happened on the live capture of 2026-08-07
    // (tests/fixtures/item_card_live.html).
    let title = null;
    const mainTitleEl = document.querySelector('[class*="mainTitle"]');
    if (mainTitleEl) {
        title = cleanText(mainTitleEl) || (mainTitleEl.getAttribute('title') || null);
    }
    if (!title) {
        const titleEl = document.querySelector('h1')
            || document.querySelector('[class*="title"], [class*="Title"]');
        title = (titleEl ? cleanText(titleEl) : null) || document.title || null;
    }

    // Price: the modern card renders symbol + text spans inside
    // highlightPrice (the amount the buyer pays) and subPrice (the
    // before-discount figure). A body-wide glyph hunt misses them: the
    // candidate spans carry digits only, and their parent's text glues Chinese
    // labels around the glyph, so the glyph-attachment check fails and THE
    // price lands among the weak candidates. Reassemble the display parts;
    // Python's coerce_price still does the parsing. Without those blocks, fall
    // back to the shared glyph hunt (older layouts).
    const priceRoot = document.querySelector('[class*="priceWrap"], [class*="PriceWrap"]') || document.body;
    let priceTexts = priceTextsIn(priceRoot);
    const assembled = [];
    for (const blockSel of ['[class*="highlightPrice"]', '[class*="subPrice"]']) {
        for (const block of priceRoot.querySelectorAll(blockSel)) {
            // The blocks render their parts as sibling spans, and the yuan
            // sign rides in a symbol-- span OR a bare text-- span depending
            // on the block (live capture: highlightPrice uses symbol--,
            // subPrice uses a second text-- span). Concatenate every part in
            // DOM order and keep results that carry digits.
            const parts = [];
            for (const el of block.querySelectorAll('[class*="symbol"], [class*="text"]')) {
                const t = cleanText(el);
                if (t) parts.push(t);
            }
            const joined = parts.join('');
            if (joined && /\\d/.test(joined)) assembled.push(joined);
        }
    }
    if (assembled.length) {
        priceTexts = {attached: assembled.concat(priceTexts.attached), other: priceTexts.other};
    }

    let shop = null, sales = null;
    // The name rides in a span[class*="shopName"] (with the same text in its
    // title attribute); the wrapping div matches the same substring and its
    // text glues the rating and service stats onto the name.
    const shopEl = document.querySelector('span[class*="shopName"]') || document.querySelector('[class*="shopName"]');
    if (shopEl) shop = cleanText(shopEl) || (shopEl.getAttribute('title') || null);
    const lines = (document.body.textContent || '').split('\\n').map(s => s.trim()).filter(Boolean);
    for (const line of lines) {
        // A glued body blob (no newlines in the live render) must never become
        // a sales/shop value — cap the candidate length like the price hunt.
        if (line.length > 40) continue;
        if (/人付款|人收货|已售/.test(line)) sales = sales || line;
        if (/店$/.test(line) && !shop) shop = line;
    }
    if (!sales) {
        // The modern card renders «已售 N+» in an unnamed colored span, and
        // the body text carries no newlines for the line scan to split. Find
        // the short text node itself; anything long is glued body text.
        // (4 === NodeFilter.SHOW_TEXT; the name itself is absent from some
        // jsdom harnesses, so the constant is spelled out.)
        const walker = document.createTreeWalker(document.body, 4);
        let node;
        while ((node = walker.nextNode())) {
            const t = (node.textContent || '').trim();
            if (t.length <= 20 && /^已售/.test(t) && /\\d/.test(t)) { sales = t; break; }
        }
    }
    const imgs = document.querySelectorAll('[class*="desc"] img, [class*="Desc"] img, #description img');
    // Same structural wall markers as the search extractor (see the comment
    // there): item pages redirect to the same title-less login wall variant,
    // and the verdict is Python's, not the browser's.
    const wallText = cleanTextWithout(document.body, ['script', 'style']) || '';
    // A card has no search-items gate: discard passive hidden widget subtrees
    // before transporting challenge text, rather than trusting its title/price.
    // 5 = SHOW_ELEMENT | SHOW_TEXT; 1/2/3 = ACCEPT/REJECT/SKIP.
    const challengeParts = [];
    const challengeWalker = document.createTreeWalker(document.body, 5, {
        acceptNode(node) {
            if (node.nodeType === 3) return 1;
            if (node.matches('script, style, [hidden], [aria-hidden="true"]')) return 2;
            const style = window.getComputedStyle(node);
            if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return 2;
            return 3;
        }
    });
    let challengeNode;
    while ((challengeNode = challengeWalker.nextNode())) {
        challengeParts.push(challengeNode.textContent || '');
    }
    return JSON.stringify({
        title: title,
        price_texts: priceTexts,
        shop_name: shop,
        sales: sales,
        description_images: imgs.length,
        page_title: document.title || '',
        anchors_total: document.querySelectorAll('a[href]').length,
        login_anchors: document.querySelectorAll('a[href*="login.jhtml"], a[href*="register.jhtml"]').length,
        body_snippet: wallText.slice(0, 2000),
        challenge_snippet: challengeParts.join('').replace(/\\s+/g, ' ').trim().slice(0, 2000)
    });
}
"""

_CARD_EXTRACT_JS = _CARD_EXTRACT_TEMPLATE.replace("//__SHARED_HELPERS__", JS_HELPERS)
# END_BLOCK_DOM_EXTRACTION


# START_BLOCK_BROWSER_READ
def _search_item_from_tile(tile: dict[str, Any]) -> TaobaoSearchItemOut:
    """Map one extracted tile onto the wire shape, parsing prices in Python.

    Accepts BOTH shapes on purpose: the extractor now returns ``price_texts``,
    but a payload cached by an older build still carries a numeric
    ``price_cny``, and a cache entry outliving a deploy must not start
    answering with nulls. The wire shape is unchanged: ``price_cny`` is a float
    or None, never 0.
    """
    price, _old = prices_from_tile(tile)
    if price is None:
        price = R.coerce_price(tile.get("price_cny"))
    return TaobaoSearchItemOut(
        item_id=tile.get("item_id"),
        title=R.flatten_text(tile.get("title")),
        price_cny=price,
        shop_name=R.flatten_text(tile.get("shop_name")),
        location=R.flatten_text(tile.get("location")),
        sales=R.flatten_text(tile.get("sales")),
        url=tile.get("url"),
    )


# START_CONTRACT: _cdp_render
# PURPOSE: Read one paced owned page, optionally polling an unfinished search grid.
# INPUTS: Validated URL, extractor source, initial settle time and optional client context.
# OUTPUTS: Capped extractor data; loading deadlines preserve the last payload for Python's timeout verdict.
# SIDE_EFFECTS: Browser navigation/handoff and same-page evaluations; no challenge polling or ad clicks.
# END_CONTRACT: _cdp_render
async def _cdp_render(url: str, extract_js: str, wait_ms: int, ctx: Context | None) -> dict[str, Any]:
    """Open ``url`` in the operator's Chrome, wait for client-side render, extract.

    Serialized via _cdp_lock: a burst of searches must not spray tabs across the
    operator's browser. Every extraction is capped like an HTTP body. An empty
    loading search grid gets at most 10 extra seconds in this same page; login
    walls and anti-bot challenges never wait. The deadline also bounds a stuck
    poll evaluation, not only the sleeps between evaluations.
    """

    def poll_needed(data: dict[str, Any]) -> bool:
        return (
            extract_js == _SEARCH_EXTRACT_JS
            and data.get("items") == []
            and _grid_still_loading(data)
            and not _login_wall_markers(data)
            and not _anti_bot_challenge(data)
        )

    async def read(page):
        async def extract() -> dict[str, Any]:
            raw = await asyncio.wait_for(page.evaluate(extract_js), timeout=30.0)
            if not isinstance(raw, str) or len(raw.encode()) > MAX_BODY_BYTES:
                raise_tool_error(TransportDownError("extracted page data missing or over the body cap"))
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise_tool_error(ParserDriftError("page extractor returned a non-object payload"))
            data.pop("_handoff_expires_at", None)
            data.pop("_handoff_id", None)
            return data

        data = await extract()
        if poll_needed(data):
            log_event(
                "[M-TAOBAO][BLOCK_BROWSER_READ] grid_loading.wait",
                extra_timeout_s=_GRID_LOADING_TIMEOUT_S,
                poll_interval_s=_GRID_POLL_INTERVAL_S,
            )
            try:
                async with asyncio.timeout(_GRID_LOADING_TIMEOUT_S):
                    while poll_needed(data):
                        await asyncio.sleep(_GRID_POLL_INTERVAL_S)
                        data = await extract()
            except TimeoutError:
                # Return the last valid read: the tool/selfcheck owns the verdict,
                # and a loading timeout must not become a catch-all transport error.
                log_event("[M-TAOBAO][BLOCK_BROWSER_READ] grid_loading.deadline")
        return data

    scope = current_client_scope(ctx)
    async with _cdp_lock:
        await _polite_wait()
        if scope is None:
            async with open_page(url, wait_ms=wait_ms) as page:
                return await read(page)
        note: dict[str, Any] = {}
        data, expires_at = await read_with_handoff(
            url=url,
            wait_ms=wait_ms,
            scope=scope,
            operation="taobao_card" if url.startswith(ITEM_BASE) else "taobao_search",
            read=read,
            challenge=_page_challenge_kind,
            note_out=note,
        )
        if note.get("resumed"):
            # R3: say what changed on the resumed page instead of leaving the
            # caller to diff two payloads. Attached only on a real resume, so an
            # ordinary first read keeps exactly the shape it had before.
            data["_resume"] = note
        if expires_at:
            data["_handoff_expires_at"] = expires_at
            data["_handoff_id"] = get_handoff_id(
                scope=scope, operation="taobao_card" if url.startswith(ITEM_BASE) else "taobao_search", url=url
            )
        return data


# END_BLOCK_BROWSER_READ

# START_BLOCK_CHALLENGE_CLASSIFICATION
# The word test for the wall body snippet: the same markers
# scripts/diagnose_drift.py proved on the live wall (its walls.login test is
# /войти|log ?in|sign ?in|登录/i over page text; the Russian branch cannot fire
# on taobao.com, so it stays out of the extractor's payload contract).
_WALL_TEXT_RE = re.compile(r"登录|log ?in|sign ?in", re.IGNORECASE)

# Calibrated on LIVE DOM readings, which no committed fixture reproduces — do
# not "prove" this ceiling against the fixtures. What is recorded: the live
# login wall of 2026-09-10 carried 33 links (same-day diagnose; the committed
# trimmed fixture counts 32 anchors), while the healthy logged-out results
# page read the same day carried 133 links (provenance comment on
# SEARCH_EXTRACTED in tests/test_server.py, repeated in the wall fixture's
# provenance file). The committed rendered captures are far poorer: the real
# extractor counts 12 anchors on search_grid_live.html (and 45 on the card
# capture item_card_live.html), so the ceiling sits ABOVE the tree's healthy
# SEARCH capture — a healthy-but-link-poor page would be eligible for the
# structural markers the moment it carries a header login link. On the live
# DOM the margin is honest: the wall (33) sits just below 40, the healthy
# reading (133) more than 3x above it. diagnose_drift.py uses the same
# ceiling to tell "this IS a wall" from "a real page with a login link in the
# header" — the gate is what keeps the structural markers from firing on a
# healthy page that happens to mention 登录.
_WALL_MAX_ANCHORS = 40


def _login_wall_markers(data: dict[str, Any]) -> tuple[str, ...]:
    """Which login-wall markers fired on an extractor payload.

    The extractor JS is dumb transport: it surfaces ``anchors_total``,
    ``login_anchors`` (anchors on the member/login.jhtml and register routes)
    and a bounded ``body_snippet`` of the visible page text. Every verdict is
    made here, where a fixture can test it. Markers:

    * ``title``        — the classic wall: 登录/login in the DOCUMENT title,
      read from the field that actually carries it for the payload kind. A
      ``page_title`` key identifies a CARD payload, where ``title`` is the
      PRODUCT name and ``page_title`` is document.title — only ``page_title``
      is consulted, so a rendered card of a product whose name says 登录 is a
      parsed page, not a wall. Search payloads carry document.title in
      ``title`` and never emit ``page_title`` — only ``title`` is consulted.
      The product name never decides this marker.
    * ``login_routes`` — login/register anchors on a link-poor page. This is
      the 2026-09-10 wall variant: EMPTY title, zero item anchors,
      /member/login.jhtml + /member/new_register.jhtml routes — 33 links in
      the live reading, 32 in the committed trimmed fixture.
    * ``body_text``    — 登录/log in/sign in wording in the visible text of a
      link-poor page (the structural test diagnose_drift.py proved live).

    Payloads without the structural fields (a cache entry written by an older
    build) fall back to the title marker alone — coerce_int(None) is None, so
    the gated markers simply stay silent instead of guessing.
    """
    markers: list[str] = []
    # The DOCUMENT title only, never the product name: card payloads carry the
    # product name in `title` and document.title in `page_title` (see
    # _CARD_EXTRACT_TEMPLATE); search payloads carry document.title in `title`
    # and emit no `page_title`. Presence of the key IS the payload kind.
    title_field = "page_title" if "page_title" in data else "title"
    doc_title = str(data.get(title_field) or "")
    if "登录" in doc_title or "login" in doc_title.lower():
        markers.append("title")
    anchors_total = R.coerce_int(data.get("anchors_total"))
    if anchors_total is not None and anchors_total < _WALL_MAX_ANCHORS:
        login_anchors = R.coerce_int(data.get("login_anchors"))
        if login_anchors is not None and login_anchors > 0:
            markers.append("login_routes")
        snippet = data.get("body_snippet")
        if isinstance(snippet, str) and _WALL_TEXT_RE.search(snippet):
            markers.append("body_text")
    return tuple(markers)


def _login_wall(data: dict[str, Any]) -> bool:
    """True when any login-wall marker fires (titled OR title-less variants)."""
    return bool(_login_wall_markers(data))


def _grid_still_loading(data: dict[str, Any]) -> bool:
    """True for a search page whose grid is still rendering, not for a wall.

    «加载中» is page text, and the captured login wall says it too; only the
    link-count gate of _login_wall_markers tells that wall apart. A page that
    offers login/register routes is a logged-out page whatever its link count,
    so it never earns the wait or the retryable timeout (pre-release audit,
    2026-10-30); with zero items it stays parser_drift, as before v2.6.0.
    """
    return data.get("grid_loading") is True and not R.coerce_int(data.get("login_anchors"))


# The word test for an anti-bot challenge page: the same wording the extractor
# JS used to match over document.body.textContent INCLUDING hidden script and
# widget text, baking title='__BLOCKED__' into the payload. Live probe
# 2026-09-10: healthy logged-out pages rendering 29-38 items answered
# __BLOCKED__ because the hidden baxia widget's text says «人机» — the selfcheck
# reported inconclusive(blocked) and the shape-drift canary never ran. The
# search verdict moved here and is gated on ZERO extracted items. Cards have
# no items gate, so their challenge_snippet also excludes hidden DOM subtrees;
# older payloads fall back to body_snippet. Both snippets exclude scripts/styles.
# 验证 also covers 验证码, so the old alternation's extra branch is not needed.
_CHALLENGE_TEXT_RE = re.compile(r"验证|人机|captcha|are you human|access denied", re.IGNORECASE)


def _anti_bot_challenge(data: dict[str, Any]) -> bool:
    """True when the payload is an anti-bot challenge rather than a catalog.

    Search challenge wording (验证/人机/captcha/…) in ``body_snippet`` is
    gated on zero extracted items. A search payload WITH items ignores hidden
    widget wording — exactly the protection the old JS verdict lacked.

    Cards instead use ``challenge_snippet``, which excludes scripts/styles and
    hidden widget subtrees. Positive visible challenge evidence is independent
    of the extracted title or price. Older card payloads without that field use
    ``body_snippet``; an explicitly empty visible snippet never falls back to
    hidden text.

    ``title == "__BLOCKED__"`` — the marker an older build's extractor JS
    baked in — is still honored, so a payload captured by that build reads
    the same; the current JS emits the raw document title and decides
    nothing. Zero items without challenge wording is NOT a challenge — that
    is the selfcheck's drift question, answered elsewhere.
    """
    if str(data.get("title") or "") == "__BLOCKED__":
        return True
    items = data.get("items")
    if isinstance(items, list) and items:
        return False
    snippet_field = "challenge_snippet" if "page_title" in data and "challenge_snippet" in data else "body_snippet"
    snippet = data.get(snippet_field)
    return isinstance(snippet, str) and bool(_CHALLENGE_TEXT_RE.search(snippet))


def _page_challenge_kind(data: dict[str, Any]) -> str | None:
    """Classify handoffs from positive wall/challenge evidence, not card fields."""
    if _login_wall_markers(data):
        return "login_or_captcha"
    return "captcha" if _anti_bot_challenge(data) else None


# END_BLOCK_CHALLENGE_CLASSIFICATION


# START_BLOCK_SEARCH_TOOL
@mcp.tool(
    name="taobao_search",
    annotations=ToolAnnotations(
        title="Taobao Search", read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=True
    ),
)
async def taobao_search(
    query: Annotated[
        str,
        Field(min_length=1, max_length=200, description="Search text, Chinese or English, e.g. '手机' or 'headphones'"),
    ],
    page: Annotated[int, Field(ge=1, le=100, description="Result page (1-based)")] = 1,
    ctx: Context | None = None,
) -> TaobaoSearchResponse:
    """Search Taobao and Tmall listings, rendered in the operator's Chrome.

    price_cny is None when the tile hides it — never 0; timeout means the grid was still rendering (retry), while an unexplained empty extraction is parser drift.

    Full field list and error codes: `guide://taobao/taobao_search`.
    """
    log_event("taobao_search.start", query=query[:60], page=page)
    try:
        url = _search_url(query, page)
        pending = has_pending_handoff(scope=current_client_scope(ctx), operation="taobao_search", url=url)
        cached = None if pending else _cache.get(url)
        if cached is not None:
            payload, tier = cached, "cache"
        else:
            try:
                payload = await _cdp_render(url, _SEARCH_EXTRACT_JS, wait_ms=6000, ctx=ctx)
            except NavBlocked as exc:
                raise_tool_error(
                    TransportDownError(
                        f"Taobao navigation blocked (HTTP {exc.status}). Check the scraping-profile Chrome and retry."
                    )
                )
            tier = "cdp"

        wall_markers = _login_wall_markers(payload)
        if wall_markers:
            log_event("taobao_search.login_wall", markers=",".join(wall_markers))
            raise_tool_error(
                ChallengeRequiredError(
                    "Taobao requires user action in the Chrome scraping profile. Complete the "
                    "login/CAPTCHA challenge there, then call this tool again after the user confirms it is done.",
                    provider="taobao",
                    challenge_type="login_or_captcha",
                    handoff_expires_at=payload.get("_handoff_expires_at"),
                    handoff_id=payload.get("_handoff_id"),
                )
            )
        if _anti_bot_challenge(payload):
            raise_tool_error(
                ChallengeRequiredError(
                    "Taobao requires CAPTCHA completion in the Chrome scraping profile, then call this "
                    "tool again after the user confirms it is done.",
                    provider="taobao",
                    handoff_expires_at=payload.get("_handoff_expires_at"),
                    handoff_id=payload.get("_handoff_id"),
                )
            )
        items_raw = payload.get("items") if isinstance(payload.get("items"), list) else []
        if not items_raw:
            if _grid_still_loading(payload):
                # The grid was still rendering when the read deadline passed:
                # nothing drifted, the page simply had no products yet. A
                # retryable timeout, not parser_drift (owner brief 2026-10-30).
                raise_tool_error(
                    UpstreamTimeoutError(
                        "Taobao's search grid was still loading when the read deadline passed — "
                        "the rendered page carried no products yet; retry the search",
                        provider="taobao",
                    )
                )
            raise_tool_error(
                ParserDriftError(
                    "rendered search page yielded zero items — either the query genuinely matched nothing or the DOM shape moved; verify manually before quoting"
                )
            )
        items = [_search_item_from_tile(it) for it in items_raw if isinstance(it, dict)]
        # Taobao prices are yuan, so the shared validator needs the field name.
        warnings: list[str] = R.validate_items(
            [it.model_dump() for it in items],
            require_title=True,
            price_key="price_cny",
            absent_price="no_prices_on_page",
        )
        # The selfcheck's family registry now also guards the tool's own
        # answer: a payload that lost a whole key family (a price alias or a
        # structural wall marker) is drift the agent must see, not only a
        # human running doctor. Zero items raise before this point, so the
        # family check never runs on a vacuously empty payload.
        drift = R.shape_drift_warning(payload, SEARCH_REQUIRED_FAMILIES, source="taobao_search")
        if drift:
            warnings.append(drift)
        result = TaobaoSearchResponse(query=query, page=page, tier_used=tier, count=len(items), items=items)
        attached = R.attach_meta(result.model_dump(by_alias=True, exclude={"meta"}), warnings, source="taobao_search")
        result.meta = MetaOut(**attached["_meta"])
        if tier == "cdp":
            _cache.set(url, payload)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("taobao_search.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"taobao_search failed: {exc}")))


@mcp.tool(
    name="taobao_card",
    annotations=ToolAnnotations(
        title="Taobao Item Card",
        read_only_hint=True,
        destructive_hint=False,
        idempotent_hint=True,
        open_world_hint=True,
    ),
)
async def taobao_card(
    item_id_or_url: Annotated[str, Field(min_length=1, max_length=300, description="Item id or item.taobao.com URL")],
    ctx: Context | None = None,
) -> TaobaoCardResponse:
    """Fetch one Taobao item card.

    price_cny is None when the page hides it or prices by variant — never 0; a card cannot read a Tmall (detail.tmall.com) listing, so use the search row for it.

    Full field list and error codes: `guide://taobao/taobao_card`.
    """
    log_event("taobao_card.start", input=item_id_or_url[:80])
    try:
        if _is_tmall_url(item_id_or_url):
            # A Tmall listing redirects to detail.tmall.com, which the card's
            # host policy refuses. Say so plainly instead of spending a
            # navigation on a refusal (owner brief 2026-10-30).
            log_event("taobao_card.tmall_refused", input=item_id_or_url[:80])
            raise_tool_error(BadRequestError(_TMALL_CARD_MESSAGE))
        item_id = _extract_item_id(item_id_or_url)
        if item_id is None:
            raise_tool_error(
                BadRequestError(
                    f"could not extract an item id from {item_id_or_url!r}; pass a 9-13 digit id or an item.taobao.com URL with ?id="
                )
            )
        url = f"{ITEM_BASE}?id={item_id}"
        pending = has_pending_handoff(scope=current_client_scope(ctx), operation="taobao_card", url=url)
        cached = None if pending else _cache.get(url)
        if cached is not None:
            payload, tier = cached, "cache"
        else:
            try:
                payload = await _cdp_render(url, _CARD_EXTRACT_JS, wait_ms=6000, ctx=ctx)
            except NavBlocked as exc:
                raise_tool_error(
                    TransportDownError(
                        f"Taobao navigation blocked (HTTP {exc.status}). Check the scraping-profile Chrome and retry."
                    )
                )
            except NavigationPolicyError as exc:
                if _is_tmall_url(exc.final_url):
                    # Taobao answers a Tmall item id with a redirect to
                    # detail.tmall.com, which this card's host policy refuses.
                    # That is a known, non-retryable limitation — say it.
                    log_event("taobao_card.tmall_refused", final_url=exc.final_url[:120])
                    raise_tool_error(BadRequestError(_TMALL_CARD_MESSAGE))
                raise_tool_error(
                    TransportDownError(
                        f"Taobao navigation left the allowed host policy ({_redact(exc.final_url)[:120]}); "
                        "check the scraping-profile Chrome and retry."
                    )
                )
            tier = "cdp"

        wall_markers = _login_wall_markers(payload)
        if wall_markers:
            log_event("taobao_card.login_wall", markers=",".join(wall_markers))
            raise_tool_error(
                ChallengeRequiredError(
                    "Taobao requires user action in the Chrome scraping profile. Complete the "
                    "login/CAPTCHA challenge there, then call this tool again after the user confirms it is done.",
                    provider="taobao",
                    challenge_type="login_or_captcha",
                    handoff_expires_at=payload.get("_handoff_expires_at"),
                    handoff_id=payload.get("_handoff_id"),
                )
            )
        if _anti_bot_challenge(payload):
            raise_tool_error(
                ChallengeRequiredError(
                    "Taobao requires CAPTCHA completion in the Chrome scraping profile, then call this "
                    "tool again after the user confirms it is done.",
                    provider="taobao",
                    handoff_expires_at=payload.get("_handoff_expires_at"),
                    handoff_id=payload.get("_handoff_id"),
                )
            )
        title = payload.get("title")
        page_title = str(payload.get("page_title") or "")
        if "不存在" in page_title or "很抱歉" in page_title:
            raise_tool_error(NotFoundError(f"Taobao item {item_id} reports itself gone ({page_title[:60]})."))
        price, _old = prices_from_tile(payload)
        if price is None:
            price = R.coerce_price(payload.get("price_cny"))
        if title is None and price is None:
            raise_tool_error(
                ParserDriftError(
                    "rendered card has neither title nor price — the item page shape moved; verify manually"
                )
            )
        # A decorative count drifting to a non-number must not kill an otherwise
        # readable card, and it is not a transport event — degrade to 0 and name
        # the drift in meta.warnings instead of leaking it to the catch-all,
        # which would misreport it as transport_down.
        card_warnings: list[str] = []
        raw_desc_images = payload.get("description_images")
        desc_images = R.coerce_int(raw_desc_images)
        if desc_images is None:
            desc_images = 0
            if raw_desc_images not in (None, 0, 0.0, ""):
                card_warnings.append(
                    f"description_images: expected a count, got {str(raw_desc_images)[:40]!r}; reported 0"
                )
        result = TaobaoCardResponse(
            item_id=item_id,
            title=title,
            price_cny=price,
            shop_name=payload.get("shop_name"),
            sales=payload.get("sales"),
            description_images=desc_images,
            url=url,
            tier_used=tier,
        )
        card = result.model_dump(by_alias=True, exclude={"meta"})
        attached = R.attach_meta(
            card,
            [*R.validate_offer(card, price_key="price_cny"), *card_warnings],
            source="taobao_card",
        )
        result.meta = MetaOut(**attached["_meta"])
        if tier == "cdp":
            _cache.set(url, payload)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("taobao_card.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"taobao_card failed: {exc}")))


# CLI-only drift canary: ``marketplace-mcp doctor`` imports and calls taobao_selfcheck()
# directly. It is deliberately NOT registered as an MCP tool — selfchecks are
# operator diagnostics, and their input/output schemas would be billed in every
# client request.
async def taobao_selfcheck(ctx: Context | None = None) -> TaobaoSelfcheckResponse:
    """Structural drift canary for Taobao (tri-state). Renders one live search
    page in the operator's Chrome and checks the extractor still finds items.

    CDP down, a login wall or an anti-bot challenge is ``inconclusive``
    (transport/session — a wall of any variant, titled or title-less, carries
    reason ``login_wall``; a challenge page carries ``blocked``), NEVER drift.
    A grid that is still rendering at the deadline is ``inconclusive`` with
    reason ``timeout``, also NEVER drift. Only a rendered page that is none of
    those and still yields zero items is ``drift``.

    ## Return Format

    TaobaoSelfcheckResponse: {status, healthy, connector, checks, server_version,
    server_started_at, process_id}.

    ## Error Format

    Raises ToolError (TransportDownError) ONLY on an unexpected internal bug
    that prevents the canary from producing any verdict. Transport/block
    failures of individual sub-checks map to inconclusive entries, not errors.
    """
    log_event("taobao_selfcheck.start")
    try:
        result = await _taobao_selfcheck_impl(ctx)
        log_event("taobao_selfcheck.done", status=result.status)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("taobao_selfcheck.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"taobao_selfcheck failed: {exc}")))


async def _taobao_selfcheck_impl(ctx: Context | None) -> TaobaoSelfcheckResponse:
    checks: dict[str, dict] = {}
    baseline = "cdp-search-v1"
    url = _search_url("手机")
    try:
        async with asyncio.timeout(90):
            payload = await _cdp_render(url, _SEARCH_EXTRACT_JS, wait_ms=6000, ctx=ctx)
    except TimeoutError:
        checks["search"] = R.selfcheck_entry(
            "inconclusive", baseline=baseline, reason="timeout", notes=["render exceeded 90s"]
        )
    except NavBlocked as exc:
        checks["search"] = R.selfcheck_entry(
            "inconclusive", baseline=baseline, reason="blocked", notes=[f"navigation http {exc.status}"]
        )
    except Exception as exc:
        checks["search"] = R.selfcheck_entry(
            "inconclusive",
            baseline=baseline,
            reason="transport_down",
            notes=[f"{type(exc).__name__}: {str(exc)[:120]}"],
        )
    else:
        wall_markers = _login_wall_markers(payload)
        if wall_markers:
            # A login wall — titled OR title-less — is a session problem, never
            # parser drift: inconclusive(login_wall), the doctrinal verdict for
            # "we were not shown the catalog because we are not logged in".
            checks["search"] = R.selfcheck_entry(
                "inconclusive",
                baseline=baseline,
                reason="login_wall",
                notes=[
                    "login wall — log into taobao.com in the scraping profile",
                    f"markers: {', '.join(wall_markers)}",
                ],
            )
        elif _anti_bot_challenge(payload):
            # An anti-bot challenge is a session/anti-bot event, never drift:
            # the canary saw the widget, not the catalog, so it can say nothing
            # about the catalog's shape. The Python verdict is gated on zero
            # items, so a healthy page whose HIDDEN widget text says 人机 falls
            # through to the shape check below — the old JS verdict stopped it
            # at inconclusive(blocked) and the canary never ran.
            checks["search"] = R.selfcheck_entry(
                "inconclusive", baseline=baseline, reason="blocked", notes=["anti-bot challenge in rendered page"]
            )
        else:
            items_raw = [*payload.get("items", [])] if isinstance(payload.get("items"), list) else []
            if items_raw:
                # Items extract — now ask the second question: did the SHAPE
                # move? The registry was measured on the captured page
                # (2026-08-07); a live payload that loses a parser-critical
                # key family is structural drift even while items come back.
                live_signature = R.shape_signature(payload)
                drift = R.diff_keys(SEARCH_SHAPE_REFERENCE, live_signature)
                missing = missing_required_families(live_signature)
                if missing:
                    checks["search"] = R.selfcheck_entry(
                        "drift",
                        baseline=baseline,
                        reason="shape_drift",
                        notes=[
                            f"{len(items_raw)} items extracted",
                            "required key families missing: " + "; ".join(", ".join(family) for family in missing),
                        ],
                        shape_missing=drift["missing"],
                        shape_added=drift["added"],
                    )
                else:
                    notes = [f"{len(items_raw)} items extracted", "shape matches the captured reference"]
                    if drift["added"]:
                        notes.append(f"{len(drift['added'])} new paths vs baseline (informational)")
                    checks["search"] = R.selfcheck_entry(
                        "healthy", baseline=baseline, notes=notes, shape_added=drift["added"]
                    )
            else:
                # Rendered, no wall, no challenge, and still zero items. Was the
                # grid still rendering? Then nothing drifted and the canary has
                # nothing to say — inconclusive(timeout), the same verdict the
                # render deadline produces (owner brief 2026-10-30).
                if _grid_still_loading(payload):
                    checks["search"] = R.selfcheck_entry(
                        "inconclusive",
                        baseline=baseline,
                        reason="timeout",
                        notes=["search grid was still loading — no products rendered before the deadline"],
                    )
                else:
                    # Rendered, no wall, no challenge, and still zero items — the
                    # only thing that means drift: the page was served and the
                    # parser could not read it.
                    checks["search"] = R.selfcheck_entry(
                        "drift",
                        baseline=baseline,
                        reason="parse_smoke_failed",
                        notes=["rendered page yielded zero items"],
                    )

    result_dict = R.selfcheck_result(
        "taobao",
        checks,
        required=("search",),
        server_version=SERVER_VERSION,
        server_started_at=SERVER_STARTED_AT,
        process_id=None,
    )
    return TaobaoSelfcheckResponse(**result_dict)


# Advertised output schemas are the dominant constant cost of an MCP mount:
# replace the full Pydantic tree with top-level field names (~64 % fewer
# wire tokens on the unified server).
apply_compact_output_schemas(mcp)

# The reference half of every tool description is served as an MCP resource
# (guide://<source>/<tool>) and the error taxonomy as marketplace://errors, so
# the agent pays for them when it reads them instead of on every request.
register_reference_resources(mcp)
