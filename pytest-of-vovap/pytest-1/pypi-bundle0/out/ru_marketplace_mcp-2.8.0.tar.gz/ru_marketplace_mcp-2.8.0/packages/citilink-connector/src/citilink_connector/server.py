"""Citilink MCP connector.

Citilink sits behind Qrator's JavaScript proof-of-work: every dynamic page answers
HTTP 401 with a ~349 KB challenge script, and the one route not behind it
(``/ajax-state/product-buy/``) wants a CSRF token you can only get from a page
that *is* behind it. No header trick clears a proof-of-work — but a real
Chrome executes it natively, so every read here runs in the operator's browser
over CDP and parses the rendered DOM.

Verified live July 2026 from a datacenter IP (docs/ANTI_BOT.md):
  - every dynamic page — 401 + Qrator challenge
  - ``restapi.citilink.ru`` — 403 even from residential (internal SSR address)
  - anonymously reachable: ``robots.txt``, ``sitemap.xml`` (~600k product URLs)

The CDP route needs verification from the operator's machine: the DOM tile
selectors below are written against the public catalog layout, and only a
challenge-passed session can confirm them. Run citilink_selfcheck from your Chrome
first — its verdict tells you which case you are in.

NEVER write to stdout in a stdio MCP server — it corrupts JSON-RPC.
"""
# START_MODULE_CONTRACT
# PURPOSE: Expose Citilink product search and cards from rendered pages.
# SCOPE: Read-only paced CDP reads; reject Qrator walls before mapping or caching.
# DEPENDS: FastMCP; mcp_core DOM/CDP/cache/pacing/kit; models_output; settings; shape_reference.
# LINKS: M-CITILINK; M-KIT; M-COMPARE; M-MARKETPLACE; packages/citilink-connector/tests.
# END_MODULE_CONTRACT
# START_MODULE_MAP
# _polite_wait: Delegate this source's pacing gap to mcp_core.kit.polite_wait.
# _extract_product_id: Validate bare handles or citilink.ru product URLs before navigation (shared host check).
# _search_item_from_tile: Normalize attached/current and old-price tile fields.
# _cdp_render: Delegate paced browser navigation and extractor execution to mcp_core.kit.render_json.
# _is_qrator_wall: Detect positive document-title or Qrator markup evidence.
# _reject_qrator_wall: Invalidate cached walls and request operator browser action.
# citilink_search: Validate rendered tiles before caching; allow nullable prices; warn when a required key vanishes.
# citilink_card: Validate before caching; warn only on in-stock missing prices.
# citilink_selfcheck: Report walls as inconclusive(blocked); not an MCP tool.
# END_MODULE_MAP

from __future__ import annotations

import asyncio
import datetime
import re
import urllib.parse
from typing import Annotated, Any

from fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from mcp_core import resilience as R
from mcp_core.cache import TTLCache
from mcp_core.dom import JS_HELPERS, prices_from_tile, title_from_tile
from mcp_core.errors import (
    BadRequestError,
    ChallengeRequiredError,
    ParserDriftError,
    ToolError,
    TransportDownError,
    raise_tool_error,
)
from mcp_core.kit import host_checked_id, polite_wait, render_json
from mcp_core.logging import log_event
from mcp_core.output_schema import apply_compact_output_schemas
from mcp_core.pacing import Pacer
from mcp_core.redact import redact_error_text as _redact
from mcp_core.resources import register_reference_resources
from mcp_core.transport.chrome_cdp import NavBlocked
from pydantic import Field

from citilink_connector.models_output import (
    CitilinkCardResponse,
    CitilinkSearchItemOut,
    CitilinkSearchResponse,
    CitilinkSelfcheckResponse,
    MetaOut,
)
from citilink_connector.settings import get_settings
from citilink_connector.shape_reference import SEARCH_REQUIRED_KEYS, SEARCH_SHAPE_REFERENCE

_settings = get_settings()

SERVER_VERSION = "2.8.0"
SERVER_STARTED_AT = datetime.datetime.now(datetime.UTC).isoformat().replace("+00:00", "Z")

SITE_BASE = "https://www.citilink.ru"
SEARCH_URL = f"{SITE_BASE}/search/"

TIMEOUT = _settings.timeout
MAX_BODY_BYTES = _settings.max_body_bytes
_min_gap = _settings.min_gap

# Real product routes, confirmed live July 2026 from a challenge-passed session:
#   citilink  /product/noutbuk-lenovo-2169270/   slug ending in a numeric id
#   dns       /product/b7a1667f9b19ed20/         16-hex id
# The original pattern demanded 24 hex — a MongoDB ObjectId shape neither site
# uses — so every search returned zero tiles and reported drift.
#
# The charset is deliberately narrower than "anything but a slash". This id is
# interpolated straight back into a URL that opens in the operator's logged-in
# Chrome, so `?`, `#`, `%` and `.` stay out: they would let a caller append a
# query string or walk the path on a page we then render with their cookies.
_ID_CHARS = r"[A-Za-z0-9_-]"
_PRODUCT_ID_RE = re.compile(rf"/product/({_ID_CHARS}+)")
_BARE_ID_RE = re.compile(rf"{_ID_CHARS}{{4,}}")

mcp = FastMCP(
    name="citilink-connector",
    version=SERVER_VERSION,
    instructions=(
        "Citilink electronics catalog: search and product cards. Every read "
        "runs in the operator's own Chrome over CDP — Qrator's proof-of-work "
        "blocks all anonymous access. Start with citilink_search; citilink_card takes a "
        "product id or citilink.ru product URL. "
        "Every tool's full field list and error codes are MCP resources (`guide://<source>/<tool>`); all error codes together are `marketplace://errors`."
    ),
)

_cache: TTLCache = TTLCache(ttl_s=_settings.cache_ttl, max_entries=128)
_pacer = Pacer(_min_gap)
_cdp_lock = asyncio.Lock()


async def _polite_wait() -> None:
    """Space this source's requests out, and back off if it refused us.

    Reads ``_min_gap`` at call time so an operator or a test can retune the
    pace without rebuilding the pacer. The pacing itself is shared
    (mcp_core.kit); this module-level name stays because the tools call it and
    the tests patch it.
    """
    await polite_wait(_pacer, _min_gap)


def _extract_product_id(raw: str) -> str | None:
    """Pull the product id out of a citilink.ru product URL or a bare id.

    Host-checked on purpose. The id is the only thing that survives this
    function, and the card URL is rebuilt from SITE_BASE, so a caller cannot
    smuggle ``/product/<id>`` into a path on someone else's domain and
    steer the operator's logged-in Chrome there. The check is the shared one
    (mcp_core.kit.host_checked_id); this pattern and this host are ours.
    """
    return host_checked_id(raw, hosts=("citilink.ru",), path_re=_PRODUCT_ID_RE, bare_re=_BARE_ID_RE)


_SEARCH_EXTRACT_TEMPLATE = """
() => {
    //__SHARED_HELPERS__
    // Search results render inside an iframe in at least one of this site's
    // layouts — confirmed live in July 2026, where the top-level document held
    // zero product anchors while the grid sat in a same-origin frame. Reading
    // only `document` makes that layout look like a dead parser. Collect the
    // frames we are allowed to read and treat them as one page.
    const docs = [document];
    for (const frame of document.querySelectorAll('iframe')) {
        try {
            if (frame.contentDocument) docs.push(frame.contentDocument);
        } catch (e) {
            // Cross-origin frame: not ours to read, and not where our tiles are.
        }
    }
    const ID_RE = /\\/product\\/([A-Za-z0-9_-]+)/;
    const out = [];
    const anchors = [];
    for (const doc of docs) {
        for (const a of doc.querySelectorAll('a[href*="/product/"]')) anchors.push(a);
    }
    const seen = new Set();
    for (const a of anchors) {
        const href = a.href || '';
        const m = href.match(ID_RE);
        if (!m || seen.has(m[1])) continue;
        seen.add(m[1]);
        // Outermost ancestor still covering one product, NOT closest(): the
        // first product anchor in a tile is often an empty image/overlay link
        // whose own class matches a [class*="product"] pattern, and closest()
        // tests the element itself first.
        const card = tileRootFor(a, ID_RE);

        // Citilink's class names are build-hashed (app-catalog-51bw0j-...), so they
        // are not selectable across deploys. What IS stable is the data-meta-*
        // contract the site uses for its own analytics — verified on captured
        // markup 2026-07-28:
        //   data-meta-name="Snippet__title"      the product name anchor
        //   data-meta-name="Snippet__price"      current price (₽ in a CHILD span)
        //   data-meta-name="Snippet__old-price"  strikethrough price, no glyph
        //   data-meta-price="59990"              machine-readable numeric price
        // The first anchor in a tile is an EMPTY overlay link, so anchor text can
        // never be the title source here.
        const titleEl = card.querySelector('[data-meta-name="Snippet__title"]');
        let title = cleanText(titleEl) || (titleEl && titleEl.getAttribute('title'));
        if (!title) {
            let fallback = null;
            for (const cand of card.querySelectorAll('a[href*="/product/"], [class*="name"], [class*="title"]')) {
                if (cleanText(cand)) { fallback = cand; break; }
            }
            title = cleanText(fallback) || a.getAttribute('title') || null;
        }

        // data-meta-price is exact and needs no parsing; keep the display strings
        // as a fallback for the day the attribute goes away.
        const metaPriceEl = card.querySelector('[data-meta-price]');
        const metaPrice = metaPriceEl ? metaPriceEl.getAttribute('data-meta-price') : null;
        const priceEl = card.querySelector('[data-meta-name="Snippet__price"]');
        const oldPriceEl = card.querySelector('[data-meta-name="Snippet__old-price"]');

        const candidates = priceTextsIn(card);
        out.push({
            product_id: m[1],
            title: title,
            price_meta: metaPrice,
            price_text: cleanText(priceEl),
            old_price_text: cleanText(oldPriceEl),
            price_texts: candidates,
            url: href
        });
        if (out.length >= 48) break;
    }
    // Qrator-specific DOM hooks are positive evidence; ordinary body words are not.
    const qratorWall = docs.some(doc => !!doc.querySelector('script[src*="qrator"], [id^="qrator"], [class^="qrator"]'));
    return JSON.stringify({items: out, title: document.title || '', qrator_wall: qratorWall});
}
"""

_CARD_EXTRACT_TEMPLATE = """
() => {
    //__SHARED_HELPERS__
    // h1 first: the generic [class*="title"] fallback can pick a section heading.
    const titleEl = document.querySelector('h1')
        || document.querySelector('[class*="product-card-top__title"]');
    // Document titles describe the page, not necessarily a product (or even a card).
    const title = cleanText(titleEl) || null;
    const qratorWall = !!document.querySelector('script[src*="qrator"], [id^="qrator"], [class^="qrator"]');

    // Scope the price hunt to the product's own buy block. Scanning the whole
    // body sweeps in recommendation snippets, instalment offers and bonus
    // amounts. On a live card the buy block is data-meta-name="PriceBlock";
    // without scoping, querySelector finds a RECOMMENDATION's Snippet__old-price
    // first and publishes another product's strikethrough as this product's old
    // price (verified against the 2026-08-06 capture: read 97 990, correct
    // 105 990). A card with NO buy block at all — out of stock — renders no
    // product price, while its recommendations still carry Snippet__price and
    // data-meta-price; without an anchor there is nothing to read, so report no
    // price rather than a neighbour's (verified: such a page read 60 630 from
    // a recommendation).
    const buyBlock = document.querySelector('[data-meta-name="ProductHeader"], [data-meta-name="PriceBlock"], [class*="product-price"], [class*="price-block"], [itemprop="offers"]');
    const metaPriceEl = buyBlock ? buyBlock.querySelector('[data-meta-price]') : null;
    const metaPrice = metaPriceEl ? metaPriceEl.getAttribute('data-meta-price') : null;
    const priceEl = buyBlock
        ? buyBlock.querySelector('[data-meta-name="PriceBlock__price"], [data-meta-name="Snippet__price"], [data-meta-name="ProductPrice__price"]')
        : null;
    const oldPriceEl = buyBlock
        ? buyBlock.querySelector('[data-meta-name="PriceBlock__additional-price"], [data-meta-name="Snippet__old-price"], [data-meta-name="ProductPrice__old-price"]')
        : null;
    const priceTexts = priceTextsIn(buyBlock);

    const bodyText = (document.body ? (document.body.textContent || '') : '');
    let available = null;
    if (/Нет в наличии|Под заказ|Закончился/i.test(bodyText)) available = false;
    else if (/В наличии|В корзину|Купить/i.test(bodyText)) available = true;

    return JSON.stringify({
        title: title,
        price_meta: metaPrice,
        price_text: cleanText(priceEl),
        old_price_text: cleanText(oldPriceEl),
        price_texts: priceTexts,
        is_available: available,
        page_title: document.title || '',
        qrator_wall: qratorWall
    });
}
"""

# The shared helpers are spliced in rather than duplicated per connector, so a
# fix to tile resolution or price selection lands everywhere at once.
_SEARCH_EXTRACT_JS = _SEARCH_EXTRACT_TEMPLATE.replace("//__SHARED_HELPERS__", JS_HELPERS)
_CARD_EXTRACT_JS = _CARD_EXTRACT_TEMPLATE.replace("//__SHARED_HELPERS__", JS_HELPERS)


def _search_item_from_tile(tile: dict[str, Any]) -> CitilinkSearchItemOut:
    """Map one extracted tile onto the wire shape, parsing prices in Python.

    Tolerates the numeric ``price_rub`` an older build cached as well as the
    ``price_texts`` candidate list the current extractor returns; the wire shape
    is identical either way, and ``price_rub`` stays float-or-None, never 0.
    """
    price, old_price = prices_from_tile(tile)
    return CitilinkSearchItemOut(
        product_id=tile.get("product_id"),
        title=title_from_tile(tile),
        price_rub=price,
        old_price_rub=old_price,
        url=tile.get("url"),
    )


async def _cdp_render(url: str, extract_js: str, wait_ms: int, ctx: Context | None) -> dict[str, Any]:
    """Open ``url`` in the operator's Chrome, let Qrator pass, extract.

    The first navigation pays the proof-of-work (wait_ms is generous for that
    reason); later reads on the same session are fast. Serialized via _cdp_lock.
    The mechanism is shared (mcp_core.kit.render_json); this module-level name
    stays because the tools call it and the tests patch it.
    """
    return await render_json(url, extract_js, wait_ms, lock=_cdp_lock, wait=_polite_wait, max_body_bytes=MAX_BODY_BYTES)


def _is_qrator_wall(data: dict[str, Any]) -> bool:
    """Require positive challenge evidence, never an empty document title."""
    # Cards keep the product title separate. Even a blank page_title is authoritative;
    # search and legacy payloads store the document title under title instead.
    title = str(data.get("page_title" if "page_title" in data else "title") or "").lower()
    return "доступ ограничен" in title or "qrator" in title or data.get("qrator_wall") is True


def _reject_qrator_wall(payload: dict[str, Any], url: str) -> None:
    """Guard fresh and legacy cached payloads before any catalog mapping."""
    if _is_qrator_wall(payload):
        _cache.invalidate(url)
        raise_tool_error(
            ChallengeRequiredError(
                "Citilink requires user action: open citilink.ru in the scraping-profile Chrome, "
                "pass the Qrator check, then retry.",
                provider="citilink",
                challenge_type="qrator",
            )
        )


@mcp.tool(
    name="citilink_search",
    annotations=ToolAnnotations(
        title="Citilink Search", read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=True
    ),
)
async def citilink_search(
    query: Annotated[str, Field(min_length=1, max_length=200, description="Search text, e.g. 'ноутбук lenovo'")],
    ctx: Context | None = None,
) -> CitilinkSearchResponse:
    """Search Citilink, rendered in the operator's Chrome.

    price_rub is None when the tile states no price — never 0.

    Full field list and error codes: `guide://citilink/citilink_search`.
    """
    log_event("citilink_search.start", query=query[:60])
    try:
        # citilink.ru reads the query from `text`; `?q=` renders the empty search
        # landing, which parses as zero tiles and looked like drift (#104).
        url = f"{SEARCH_URL}?text={urllib.parse.quote(query.strip())}"
        cached = _cache.get(url)
        if cached is not None:
            payload, tier = cached, "cache"
        else:
            try:
                payload = await _cdp_render(url, _SEARCH_EXTRACT_JS, wait_ms=8000, ctx=ctx)
            except NavBlocked as exc:
                raise_tool_error(
                    TransportDownError(
                        f"Citilink navigation blocked (HTTP {exc.status}). The Qrator challenge must pass in the scraping-profile Chrome — open citilink.ru there once, then retry."
                    )
                )
            tier = "cdp"
        _reject_qrator_wall(payload, url)
        items_raw = payload.get("items") if isinstance(payload.get("items"), list) else []
        if not items_raw:
            raise_tool_error(
                ParserDriftError(
                    "rendered search page yielded zero product tiles — either the query matched nothing or the DOM shape moved; verify manually"
                )
            )
        items = [_search_item_from_tile(it) for it in items_raw if isinstance(it, dict)]
        warnings: list[str] = R.validate_items(
            [it.model_dump() for it in items], require_title=True, absent_price="no_prices_on_page"
        )
        # The selfcheck compares this payload against the captured
        # required-key registry; the tool's own answer now carries the same
        # drift signal, so an agent does not need a human running doctor to
        # learn the shape moved. Zero tiles raise before this point, so the
        # key check never runs on a vacuously empty payload.
        drift = R.shape_drift_warning(payload, ((key,) for key in SEARCH_REQUIRED_KEYS), source="citilink_search")
        if drift:
            warnings.append(drift)
        result = CitilinkSearchResponse(query=query, tier_used=tier, count=len(items), items=items)
        attached = R.attach_meta(result.model_dump(by_alias=True, exclude={"meta"}), warnings, source="citilink_search")
        result.meta = MetaOut(**attached["_meta"])
        if tier == "cdp":
            _cache.set(url, payload)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("citilink_search.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"citilink_search failed: {exc}")))


@mcp.tool(
    name="citilink_card",
    annotations=ToolAnnotations(
        title="Citilink Product Card",
        read_only_hint=True,
        destructive_hint=False,
        idempotent_hint=True,
        open_world_hint=True,
    ),
)
async def citilink_card(
    product_url: Annotated[
        str,
        Field(
            min_length=1,
            max_length=400,
            description="citilink.ru product URL containing /product/<slug>/, e.g. /product/noutbuk-lenovo-2169270/",
        ),
    ],
    ctx: Context | None = None,
) -> CitilinkCardResponse:
    """Fetch one Citilink product card.

    price_rub and old_price_rub are None when the card states none — never 0.

    Full field list and error codes: `guide://citilink/citilink_card`.
    """
    log_event("citilink_card.start", input=product_url[:80])
    try:
        product_id = _extract_product_id(product_url)
        if product_id is None:
            raise_tool_error(
                BadRequestError(
                    f"could not extract a product id from {product_url!r}; pass a citilink.ru URL with /product/<slug>/ "
                    f"(the slug ends in a numeric id, e.g. /product/noutbuk-lenovo-2169270/)"
                )
            )
        # Rebuild from SITE_BASE rather than navigating what the caller passed:
        # this page opens in the operator's own logged-in Chrome, so the target
        # host must come from us, never from the argument.
        url = f"{SITE_BASE}/product/{product_id}/"
        cached = _cache.get(url)
        if cached is not None:
            payload, tier = cached, "cache"
        else:
            try:
                payload = await _cdp_render(url, _CARD_EXTRACT_JS, wait_ms=8000, ctx=ctx)
            except NavBlocked as exc:
                raise_tool_error(TransportDownError(f"Citilink navigation blocked (HTTP {exc.status})."))
            tier = "cdp"
        _reject_qrator_wall(payload, url)
        title = title_from_tile(payload)
        price, old_price = prices_from_tile(payload)
        if title is None and price is None:
            raise_tool_error(
                ParserDriftError("rendered card has neither title nor price — the card shape moved; verify manually")
            )
        # Canary for the silent-None hole: if the card says it is in stock but no
        # price block matched any buy-block anchor, the layout most likely moved.
        # Without this, the tool would hand back price_rub=None with no signal.
        # (An unavailable card legitimately has no price block, so no warning there.)
        card_warnings: list[str] = []
        if payload.get("is_available") and price is None:
            card_warnings.append(
                "in_stock_no_price: card is available but no price block matched — "
                "the buy-block layout may have moved; verify manually"
            )
        result = CitilinkCardResponse(
            product_id=product_id,
            title=title,
            price_rub=price,
            old_price_rub=old_price,
            is_available=payload.get("is_available"),
            url=url,
            tier_used=tier,
        )
        # The card's own fields, plus the buy-block warning above; the offer
        # invariants report a price that parsed into something unparseable.
        card = result.model_dump(by_alias=True, exclude={"meta"})
        attached = R.attach_meta(card, [*R.validate_offer(card), *card_warnings], source="citilink_card")
        result.meta = MetaOut(**attached["_meta"])
        if tier == "cdp":
            _cache.set(url, payload)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("citilink_card.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"citilink_card failed: {exc}")))


# CLI-only drift canary: ``marketplace-mcp doctor`` imports and calls citilink_selfcheck()
# directly. It is deliberately NOT registered as an MCP tool — selfchecks are
# operator diagnostics, and their input/output schemas would be billed in every
# client request.
async def citilink_selfcheck(ctx: Context | None = None) -> CitilinkSelfcheckResponse:
    """Structural drift canary for Citilink (tri-state). Renders one live search
    page in the operator's Chrome and checks tiles extract.

    A detected Qrator wall is ``inconclusive`` with reason ``blocked``; CDP-down
    is ``inconclusive`` with reason ``transport_down``, NEVER drift. Rendered
    pages without challenge evidence can report tile or required-shape drift.

    ## Return Format

    CitilinkSelfcheckResponse: {status, healthy, connector, checks, ...}.

    ## Error Format

    Raises ToolError (TransportDownError) ONLY on an unexpected internal bug
    that prevents the canary from producing any verdict. Transport/block
    failures of individual sub-checks map to inconclusive entries, not errors.
    """
    log_event("citilink_selfcheck.start")
    try:
        result = await _citilink_selfcheck_impl(ctx)
        log_event("citilink_selfcheck.done", status=result.status)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("citilink_selfcheck.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"citilink_selfcheck failed: {exc}")))


async def _citilink_selfcheck_impl(ctx: Context | None) -> CitilinkSelfcheckResponse:
    checks: dict[str, dict] = {}
    baseline = "cdp-search-shape-v1"
    url = f"{SEARCH_URL}?text={urllib.parse.quote('ноутбук')}"
    try:
        async with asyncio.timeout(90):
            payload = await _cdp_render(url, _SEARCH_EXTRACT_JS, wait_ms=8000, ctx=ctx)
    except TimeoutError:
        checks["search"] = R.selfcheck_entry(
            "inconclusive", baseline=baseline, reason="timeout", notes=["render exceeded 90s"]
        )
    except Exception as exc:
        checks["search"] = R.selfcheck_entry(
            "inconclusive",
            baseline=baseline,
            reason="transport_down",
            notes=[f"{type(exc).__name__}: {str(exc)[:120]}"],
        )
    else:
        items_raw = payload.get("items") if isinstance(payload.get("items"), list) else []
        if _is_qrator_wall(payload):
            checks["search"] = R.selfcheck_entry(
                "inconclusive", baseline=baseline, reason="blocked", notes=["Qrator challenge in rendered page"]
            )
        elif items_raw:
            # Tiles extract — now ask the second question: did the SHAPE move?
            # The registry was measured on a captured page; a live payload that
            # loses a parser-critical path is structural drift even while tiles
            # still come back. Types may vary with the data (str/null), so the
            # required check is on key presence, not on the full signature.
            live_signature = R.shape_signature(payload)
            drift = R.diff_keys(SEARCH_SHAPE_REFERENCE, live_signature)
            missing_required = [
                key for key in SEARCH_REQUIRED_KEYS if not any(entry.startswith(f"{key}:") for entry in live_signature)
            ]
            if missing_required:
                checks["search"] = R.selfcheck_entry(
                    "drift",
                    baseline=baseline,
                    reason="shape_drift",
                    notes=[
                        f"{len(items_raw)} tiles extracted",
                        f"required paths missing: {', '.join(missing_required)}",
                    ],
                    shape_missing=drift["missing"],
                    shape_added=drift["added"],
                )
            else:
                notes = [f"{len(items_raw)} tiles extracted", "shape matches the captured reference"]
                if drift["added"]:
                    notes.append(f"{len(drift['added'])} new paths vs baseline (informational)")
                checks["search"] = R.selfcheck_entry(
                    "healthy", baseline=baseline, notes=notes, shape_added=drift["added"]
                )
        else:
            checks["search"] = R.selfcheck_entry(
                "drift", baseline=baseline, reason="parse_smoke_failed", notes=["zero tiles"]
            )

    result_dict = R.selfcheck_result(
        "citilink",
        checks,
        required=("search",),
        server_version=SERVER_VERSION,
        server_started_at=SERVER_STARTED_AT,
        process_id=None,
    )
    return CitilinkSelfcheckResponse(**result_dict)


# Advertised output schemas are the dominant constant cost of an MCP mount:
# replace the full Pydantic tree with top-level field names (~64 % fewer
# wire tokens on the unified server).
apply_compact_output_schemas(mcp)

# The reference half of every tool description is served as an MCP resource
# (guide://<source>/<tool>) and the error taxonomy as marketplace://errors, so
# the agent pays for them when it reads them instead of on every request.
register_reference_resources(mcp)
