"""Lamoda MCP connector.

Lamoda's GraphQL product endpoint enriches a known SKU with real prices,
brands, sizes and availability. Discovery — search, catalog, HTML pages —
runs in the operator's Chrome over CDP because plain HTTPS is blocked.

Verified live July 2026 from a datacenter IP (docs/ANTI_BOT.md):
  - ``POST /goapi/v2/catalog/graphql/products/`` — then 200, real JSON (tier 1)
  - catalog/search GET paths — 307 loop; HTML — 403; mobile API — 403
  - ``rating`` is not in the GraphQL schema (introspection disabled), so this
    connector reports no review data — Lamoda hides it entirely

2026-10-12: the GraphQL endpoint answers plain HTTPS with a 307 loop too;
the card falls back to an in-page POST in the operator's Chrome, which
answers 200 with the normal Lamoda envelope.

Two tiers, tried in cost order: HTTPS GraphQL first for cards, then one CDP
GraphQL POST on transport failure. Search uses CDP directly. Run
lamoda_selfcheck from your Chrome to check both paths.

NEVER write to stdout in a stdio MCP server — it corrupts JSON-RPC.
"""
# START_MODULE_CONTRACT
# PURPOSE: Expose Lamoda product discovery and SKU enrichment.
# SCOPE: Read-only HTTPS GraphQL cards with CDP POST fallback; browser search and challenge recovery handoffs.
# DEPENDS: FastMCP; httpx; mcp_core DOM/CDP/handoff/cache/kit; models_output; settings; shape_reference.
# LINKS: M-LAMODA; M-KIT; M-COMPARE; M-MARKETPLACE; packages/lamoda-connector/tests.
# END_MODULE_CONTRACT
# START_MODULE_MAP
# _extract_sku: Resolve and normalize SKU handles or product URLs.
# _search_item_from_tile: Normalize rendered price/title fields.
# _graphql_via_https: POST the SKU query over plain HTTPS and return status/body.
# _graphql_via_cdp: POST the query inside the operator's Chrome with bounded transport.
# _graphql_card: Try HTTPS then CDP; parse and cache GraphQL product details, sizes and stock.
# _cdp_render_search: Read browser search and recover explicit challenge handoffs.
# lamoda_search: Return rendered catalog tiles with nullable prices; warn when a required key family vanishes.
# lamoda_card: Return GraphQL-backed SKU details and availability.
# lamoda_selfcheck: Diagnose operator endpoint/parser health; not an MCP tool.
# END_MODULE_MAP

from __future__ import annotations

import asyncio
import datetime
import json
import re
import urllib.parse
from typing import Annotated, Any

import httpx
from fastmcp import Context, FastMCP
from mcp.types import ToolAnnotations
from mcp_core import resilience as R
from mcp_core.cache import TTLCache
from mcp_core.dom import JS_HELPERS, prices_from_tile, title_from_tile
from mcp_core.errors import (
    BadRequestError,
    ChallengeRequiredError,
    NotFoundError,
    ParserDriftError,
    ToolError,
    TransportDownError,
    raise_tool_error,
)
from mcp_core.kit import polite_wait
from mcp_core.logging import log_event
from mcp_core.output_schema import apply_compact_output_schemas
from mcp_core.pacing import Pacer
from mcp_core.redact import redact_error_text as _redact
from mcp_core.resources import register_reference_resources
from mcp_core.runtime import browser_handoff_lifespan, current_client_scope
from mcp_core.transport import build_client
from mcp_core.transport.browser_handoff import get_handoff_id, has_pending_handoff, read_with_handoff
from mcp_core.transport.chrome_cdp import NavBlocked, open_page
from pydantic import Field

from lamoda_connector.models_output import (
    LamodaCardResponse,
    LamodaSearchItemOut,
    LamodaSearchResponse,
    LamodaSelfcheckResponse,
    LamodaSizeOut,
    MetaOut,
)
from lamoda_connector.settings import get_settings
from lamoda_connector.shape_reference import (
    SEARCH_REQUIRED_FAMILIES,
    SEARCH_SHAPE_REFERENCE,
    missing_required_families,
)

_settings = get_settings()

SERVER_VERSION = "2.8.0"
SERVER_STARTED_AT = datetime.datetime.now(datetime.UTC).isoformat().replace("+00:00", "Z")

SITE_BASE = "https://www.lamoda.ru"
GRAPHQL_URL = f"{SITE_BASE}/goapi/v2/catalog/graphql/products/"

TIMEOUT = _settings.timeout
MAX_BODY_BYTES = _settings.max_body_bytes
_min_gap = _settings.min_gap

# SKUs look like MP002XM1RMM3: two letters, alphanumerics, 8-20 chars. URLs
# carry them lowercased, so match case-insensitively and normalise to upper.
_SKU_RE = re.compile(r"\b([a-zA-Z]{2}[a-zA-Z0-9]{6,18})\b")

# Field names verified against the live endpoint, July 2026. `old_price_amount`
# is the real name: asking for `old_price` answers HTTP 200 with
# {"error": "Internal server error", "code": -32603} and no data at all.
_GRAPHQL_QUERY = (
    "query { products(skus: [%s]) { sku name brand_name price_amount old_price_amount "
    "is_available is_sellable stock_remains sizes { size is_available stock_remains } } }"
)

_HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9",
}

mcp = FastMCP(
    name="lamoda-connector",
    lifespan=browser_handoff_lifespan,
    version=SERVER_VERSION,
    instructions=(
        "Lamoda fashion catalog: text search runs in the operator's Chrome over "
        "CDP (discovery is behind a redirect loop); product cards come from the "
        "GraphQL endpoint: HTTPS first, then an in-page Chrome POST if blocked. Lamoda exposes no ratings. "
        "Start with lamoda_search; lamoda_card takes a SKU or product URL. "
        "Every tool's full field list and error codes are MCP resources (`guide://<source>/<tool>`); all error codes together are `marketplace://errors`."
    ),
)

_cache: TTLCache = TTLCache(ttl_s=_settings.cache_ttl, max_entries=128)
_pacer = Pacer(_min_gap)
_cdp_lock = asyncio.Lock()


def _proxy() -> str | None:
    return _settings.proxy.get_secret_value() or None


async def _polite_wait() -> None:
    """Space this source's requests out, and back off if it refused us.

    Reads ``_min_gap`` at call time so an operator or a test can retune the
    pace without rebuilding the pacer. The pacing itself is shared
    (mcp_core.kit.polite_wait); this module-level name stays because the tools
    call it and the tests patch it.
    """
    await polite_wait(_pacer, _min_gap)


def _extract_sku(raw: str) -> str | None:
    """Pull a SKU out of a lamoda.ru URL or a bare SKU string.

    URLs carry the SKU lowercased (``/p/mp002xm1rmm3/``); the GraphQL endpoint
    expects the canonical uppercase form.
    """
    raw = raw.strip()
    match = _SKU_RE.search(raw)
    return match.group(1).upper() if match else None


_SEARCH_EXTRACT_TEMPLATE = """
() => {
    //__SHARED_HELPERS__
    const ID_RE = /\\/p\\/([a-zA-Z]{2}[a-zA-Z0-9]{6,18})/i;
    // A node whose whole text is a discount percentage ("−49%") is a badge,
    // never a name. Lamoda renders that badge INSIDE the image anchor, which
    // is how an anchor-first title read reported the discount as the title
    // (live capture 2026-08-07, tests/fixtures/search_grid_live.html).
    const BADGE_RE = /^[−\\-]?\\d+\\s*%$/;
    const out = [];
    const anchors = document.querySelectorAll('a[href*="/p/"]');
    const seen = new Set();
    for (const a of anchors) {
        const href = a.href || '';
        const m = href.match(ID_RE);
        if (!m || seen.has(m[1])) continue;
        seen.add(m[1]);
        // tileRootFor, not closest(): closest() tests the anchor itself first, so
        // an image/overlay link whose own class contains "card" or "product"
        // becomes the tile and reads as empty. See mcp_core.dom.
        const card = tileRootFor(a, ID_RE);
        // The product name first, then weaker name/title/brand candidates, the
        // anchor text only as a last resort. Selector classes are checked in
        // priority order, not document order: the badge span sits earliest in
        // the tile DOM and would win a document-order walk.
        let titleEl = null;
        for (const sel of ['[class*="product-name"]', '[class*="name"]', '[class*="title"]', '[class*="brand"]']) {
            for (const cand of card.querySelectorAll(sel)) {
                const t = cleanText(cand);
                if (t && !BADGE_RE.test(t)) { titleEl = cand; break; }
            }
            if (titleEl) break;
        }
        if (!titleEl) titleEl = a;
        const title = cleanText(titleEl) || (a.getAttribute('title') || null);
        // Scope the price hunt to the price block when the layout names one:
        // the live size grid feeds concatenated digit blobs ("3535,53636,5...")
        // into the weak candidates, and the largest of them gets promoted to
        // the strikethrough — a 3.5e16-rouble "old price". Same framing
        // doctrine as the Citilink PriceBlock scope.
        const priceRoot = card.querySelector('[class*="price-wrap"]') || card;
        out.push({
            sku: m[1],
            title: title,
            brand: null,
            price_texts: priceTextsIn(priceRoot),
            url: href
        });
        if (out.length >= 48) break;
    }
    // Challenge words also occur in scripts, hidden anti-bot widgets and even
    // product copy. Keep this as raw transport data; the Python classifier
    // decides whether an empty page is a challenge. In particular, never let
    // a hidden/script marker override a healthy product grid.
    const bodyCopy = document.body ? document.body.cloneNode(true) : null;
    if (bodyCopy) {
        for (const node of bodyCopy.querySelectorAll('script, style, noscript, [hidden]')) node.remove();
        for (const node of bodyCopy.querySelectorAll('[style]')) {
            const style = node.getAttribute('style') || '';
            if (/display\\s*:\\s*none|visibility\\s*:\\s*hidden/i.test(style)) node.remove();
        }
    }
    const bodyText = (bodyCopy && bodyCopy.textContent || '').replace(/\\s+/g, ' ').trim();
    return JSON.stringify({items: out, title: document.title || '', body_snippet: bodyText.slice(0, 2000)});
}
"""

# Spliced rather than duplicated: one fix to tile resolution or price selection
# lands on every CDP source at once.
_SEARCH_EXTRACT_JS = _SEARCH_EXTRACT_TEMPLATE.replace("//__SHARED_HELPERS__", JS_HELPERS)


# The extractor only transports a bounded visible-text sample. Keep challenge
# wording in one Python classifier so product copy and hidden widgets cannot
# change the verdict while a healthy grid is present. ``бота`` on its own is
# deliberately absent: it occurs in ordinary product copy and is not evidence
# of a challenge.
_CHALLENGE_TEXT_RE = re.compile(r"провер|не\s+робот|captcha|are\s+you\s+human|access\s+denied", re.IGNORECASE)


def _anti_bot_challenge(data: dict[str, Any]) -> bool:
    """Return whether an empty rendered page is an anti-bot challenge.

    ``__BLOCKED__`` is retained only for the legacy cached payload shape and
    only when it carried no items. Current extractor payloads carry a raw
    ``body_snippet`` and the wording is classified here in Python.
    """
    items = data.get("items")
    if isinstance(items, list) and items:
        return False
    if str(data.get("title") or "") == "__BLOCKED__":
        return True
    snippet = data.get("body_snippet")
    return isinstance(snippet, str) and bool(_CHALLENGE_TEXT_RE.search(snippet))


def _search_item_from_tile(tile: dict[str, Any]) -> LamodaSearchItemOut:
    """Map one extracted tile onto the wire shape, parsing prices in Python.

    Accepts the numeric ``price_rub`` an older build cached alongside the current
    ``price_texts`` candidates; the wire shape does not change either way.
    """
    price, old_price = prices_from_tile(tile)
    return LamodaSearchItemOut(
        sku=tile.get("sku"),
        title=title_from_tile(tile),
        brand=title_from_tile({"title": tile.get("brand")}),
        price_rub=price,
        old_price_rub=old_price,
        url=tile.get("url"),
    )


# Transport only, following Cian's in-page POST pattern. Read in bounded chunks
# before serialising through CDP, not with res.text() on an unbounded response.
# Lamoda's anti-bot interstitial lives under this path (seen live 2026-10-12, also on
# Megamarket); the wording check above only counts on a near-empty page.
_CHALLENGE_PATH = "/xpvnsulc/"
_JS_BODY_SNIPPET = "() => ((document.body && document.body.innerText) || '').slice(0, 2000)"

_JS_POST = """async (args) => {
    const res = await fetch(args.url, {
        method: 'POST',
        credentials: 'include',
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
        body: JSON.stringify(args.body)
    });
    const reader = res.body.getReader();
    let total = 0;
    const chunks = [];
    while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        total += value.length;
        if (total > args.cap) {
            await reader.cancel();
            return JSON.stringify({status: 0, text: 'BODY_CAP_EXCEEDED'});
        }
        chunks.push(value);
    }
    const buf = new Uint8Array(total);
    let off = 0;
    for (const c of chunks) { buf.set(c, off); off += c.length; }
    return JSON.stringify({status: res.status, text: new TextDecoder().decode(buf)});
}"""


async def _graphql_via_https(query: str, sku: str) -> tuple[int, str]:
    """Tier 1: return the status and body of a plain HTTPS GraphQL POST."""
    headers = dict(_HEADERS)
    headers["Referer"] = f"{SITE_BASE}/p/{sku.lower()}/"
    async with build_client(timeout_s=TIMEOUT, headers=headers, proxy=_proxy()) as client:
        response = await client.post(GRAPHQL_URL, json={"query": query})
    if response.status_code == 200 and len(response.content) > MAX_BODY_BYTES:
        raise_tool_error(TransportDownError("GraphQL body over the cap"))
    return response.status_code, response.text


async def _graphql_via_cdp(query: str, ctx: Context | None) -> tuple[int, str]:
    """Tier 2: POST from a loaded Lamoda tab carrying the operator's cookies."""

    async def _attempt() -> tuple[int, str]:
        # open_page defaults to the origin host (www.lamoda.ru); no extra hosts.
        async with _cdp_lock, open_page(f"{SITE_BASE}/", wait_ms=4000) as page:
            # A landing that stopped on the anti-bot page cannot post anything; say
            # so at once instead of waiting out the fetch timeout (live 2026-10-12).
            snippet = await asyncio.wait_for(page.evaluate(_JS_BODY_SNIPPET), timeout=10.0)
            if _CHALLENGE_PATH in str(page.url) or (
                isinstance(snippet, str) and len(snippet) < 1000 and _CHALLENGE_TEXT_RE.search(snippet)
            ):
                raise_tool_error(
                    ChallengeRequiredError(
                        "Lamoda requires user action in the connected Chrome. Complete the challenge "
                        "on lamoda.ru, then call this tool again after the user confirms it is done.",
                        provider="lamoda",
                    )
                )
            raw = await asyncio.wait_for(
                page.evaluate(_JS_POST, {"url": GRAPHQL_URL, "body": {"query": query}, "cap": MAX_BODY_BYTES}),
                timeout=30.0,
            )
        result = json.loads(raw) if isinstance(raw, str) else raw
        return int(result["status"]), str(result["text"])

    try:
        return await asyncio.wait_for(_attempt(), timeout=max(0.01, float(TIMEOUT)))
    except TimeoutError:
        return 0, f"CDP timeout after {TIMEOUT}s"
    except NavBlocked as exc:
        return exc.status or 0, _redact(str(exc))


async def _graphql_card(sku: str, ctx: Context | None) -> dict[str, Any]:
    """Fetch and cache SKU enrichment: HTTPS first, one CDP fallback if refused."""
    cache_key = f"graphql:{sku}"
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached
    await _polite_wait()
    query = _GRAPHQL_QUERY % json.dumps(sku)
    tier = "graphql"
    try:
        status_code, text = await _graphql_via_https(query, sku)
        https_outcome = f"HTTP {status_code} over HTTPS. Body preview: {_redact(text[:200]) or '<empty>'}"
    except httpx.TransportError as exc:
        status_code, text = 0, ""
        https_outcome = f"{type(exc).__name__} over HTTPS: {_redact(str(exc))}"
    if status_code != 200:
        tier = "graphql_cdp"
        try:
            status_code, text = await _graphql_via_cdp(query, ctx)
        except ToolError:
            raise
        except Exception as exc:
            status_code, text = 0, _redact(f"{type(exc).__name__}: {exc}")
        if status_code != 200:
            chrome_outcome = f"HTTP {status_code} via Chrome" if status_code else "transport failure via Chrome"
            raise_tool_error(
                TransportDownError(
                    f"Lamoda GraphQL: {https_outcome}; {chrome_outcome}. "
                    f"Body preview: {_redact(text[:200]) or '<empty>'}",
                    status_code=status_code or None,
                )
            )
    log_event("lamoda_graphql.answered", tier_used=tier, status_code=status_code)
    if len(text.encode()) > MAX_BODY_BYTES:
        raise_tool_error(TransportDownError("GraphQL body over the cap"))
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        raise_tool_error(ParserDriftError(f"non-JSON GraphQL body; preview: {text[:200]}"))
    # Lamoda does not use the standard GraphQL envelope. Captured live in July
    # 2026 against the real endpoint:
    #   found      {"error": null, "result": [{…}]}
    #   unknown    {"error": null, "result": null}
    #   bad field  {"error": "Internal server error", "code": -32603}
    # The products live under `result`, not `data.products`, and a failure comes
    # back as a single `error` string rather than an `errors` array. Reading the
    # standard shape meant every response looked like drift.
    upstream_error = payload.get("error")
    if isinstance(upstream_error, str) and upstream_error:
        code = payload.get("code")
        suffix = f" (code {code})" if code is not None else ""
        raise_tool_error(
            ParserDriftError(
                f"Lamoda GraphQL rejected the query: {upstream_error[:160]}{suffix}. "
                "A wrong field name in the query is the usual cause."
            )
        )
    errors = payload.get("errors")
    if isinstance(errors, list) and errors:
        # Kept as a fallback in case Lamoda ever moves to the standard shape.
        first = errors[0] if isinstance(errors[0], dict) else {}
        detail = str(first.get("message") or errors[0])[:200]
        raise_tool_error(ParserDriftError(f"Lamoda GraphQL rejected the query: {detail}"))

    products = payload.get("result")
    if products is None:
        data = payload.get("data")
        products = data.get("products") if isinstance(data, dict) else None
    if products is None:
        # `result: null` is how an unknown SKU comes back — a real not-found,
        # not a broken parser.
        raise_tool_error(NotFoundError(f"Lamoda SKU {sku} returned no product."))
    if not isinstance(products, list):
        raise_tool_error(ParserDriftError(f"GraphQL result is {type(products).__name__}, expected a list"))
    if not products:
        raise_tool_error(NotFoundError(f"Lamoda SKU {sku} returned no product."))
    product = products[0]
    if not isinstance(product, dict):
        raise_tool_error(ParserDriftError("GraphQL product entry is not an object"))
    # Keep the answered tier with the successful product so cache hits do not
    # misreport a browser-backed card as a plain HTTPS response.
    product = {**product, "_tier_used": tier}
    _cache.set(cache_key, product)
    return product


async def _cdp_render_search(query: str, ctx: Context | None) -> dict[str, Any]:
    """Tier-2: render the search page in the operator's Chrome, extract tiles."""
    cache_key = f"search:{query}"
    url = f"{SITE_BASE}/catalogsearch/result/?q={urllib.parse.quote(query)}"
    scope = current_client_scope(ctx)
    pending = has_pending_handoff(scope=scope, operation="lamoda_search", url=url)
    cached = None if pending else _cache.get(cache_key)
    if cached is not None:
        return cached

    async def _attempt() -> dict[str, Any]:
        async def read(page):
            raw = await asyncio.wait_for(page.evaluate(_SEARCH_EXTRACT_JS), timeout=30.0)
            if not isinstance(raw, str) or len(raw.encode()) > MAX_BODY_BYTES:
                raise_tool_error(TransportDownError("extracted page data missing or over the body cap"))
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise_tool_error(ParserDriftError("search extractor returned a non-object payload"))
            data.pop("_handoff_expires_at", None)
            data.pop("_handoff_id", None)
            return data

        async with _cdp_lock:
            await _polite_wait()
            if scope is None:
                async with open_page(url, wait_ms=8000) as page:
                    return await read(page)
            note: dict = {}
            data, expires_at = await read_with_handoff(
                url=url,
                wait_ms=8000,
                scope=scope,
                operation="lamoda_search",
                read=read,
                challenge=lambda payload: "captcha" if _anti_bot_challenge(payload) else None,
                note_out=note,
            )
            if note.get("resumed"):
                # R3: a resumed read states what changed (challenge cleared, data
                # moved) rather than making the caller diff two payloads.
                data["_resume"] = note
            if expires_at:
                data["_handoff_expires_at"] = expires_at
                data["_handoff_id"] = get_handoff_id(scope=scope, operation="lamoda_search", url=url)
            return data

    try:
        payload = await asyncio.wait_for(_attempt(), timeout=max(0.01, float(TIMEOUT)))
    except TimeoutError:
        raise_tool_error(TransportDownError(f"CDP timeout after {TIMEOUT}s"))
    if not _anti_bot_challenge(payload):
        _cache.set(cache_key, payload)
    return payload


@mcp.tool(
    name="lamoda_search",
    annotations=ToolAnnotations(
        title="Lamoda Search", read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=True
    ),
)
async def lamoda_search(
    query: Annotated[str, Field(min_length=1, max_length=200, description="Search text, e.g. 'кроссовки nike'")],
    ctx: Context | None = None,
) -> LamodaSearchResponse:
    """Search Lamoda, rendered in the operator's Chrome (discovery is blocked tier 1).

    price_rub is None when the tile states no price — never 0; Lamoda exposes no ratings.

    Full field list and error codes: `guide://lamoda/lamoda_search`.
    """
    log_event("lamoda_search.start", query=query[:60])
    try:
        try:
            payload = await _cdp_render_search(query.strip(), ctx)
        except NavBlocked as exc:
            raise_tool_error(TransportDownError(f"Lamoda navigation blocked (HTTP {exc.status})."))
        if _anti_bot_challenge(payload):
            raise_tool_error(
                ChallengeRequiredError(
                    "Lamoda requires user action in the connected Chrome. Complete the challenge on "
                    "lamoda.ru, then call this tool again after the user confirms it is done.",
                    provider="lamoda",
                    handoff_expires_at=payload.get("_handoff_expires_at"),
                    handoff_id=payload.get("_handoff_id"),
                )
            )
        items_raw = payload.get("items") if isinstance(payload.get("items"), list) else []
        if not items_raw:
            raise_tool_error(
                ParserDriftError(
                    "rendered search page yielded zero SKUs — either the query matched nothing or the tile shape moved; verify manually"
                )
            )
        items = [_search_item_from_tile(it) for it in items_raw if isinstance(it, dict)]
        warnings: list[str] = R.validate_items(
            [it.model_dump() for it in items], require_title=True, absent_price="no_prices_on_page"
        )
        # The selfcheck's family registry now also guards the tool's own
        # answer: a payload that lost a whole key family is drift the agent
        # must see, not only a human running doctor. The four render-based
        # connectors raise on zero items before this point, so the family
        # check never runs on a vacuously empty payload.
        drift = R.shape_drift_warning(payload, SEARCH_REQUIRED_FAMILIES, source="lamoda_search")
        if drift:
            warnings.append(drift)
        result = LamodaSearchResponse(query=query, tier_used="cdp", count=len(items), items=items)
        attached = R.attach_meta(result.model_dump(by_alias=True, exclude={"meta"}), warnings, source="lamoda_search")
        result.meta = MetaOut(**attached["_meta"])
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("lamoda_search.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"lamoda_search failed: {exc}")))


@mcp.tool(
    name="lamoda_card",
    annotations=ToolAnnotations(
        title="Lamoda Product Card",
        read_only_hint=True,
        destructive_hint=False,
        idempotent_hint=True,
        open_world_hint=True,
    ),
)
async def lamoda_card(
    sku_or_url: Annotated[
        str, Field(min_length=1, max_length=300, description="SKU (MP002XM1RMM3) or lamoda.ru product URL")
    ],
    ctx: Context | None = None,
) -> LamodaCardResponse:
    """Fetch a GraphQL card over HTTPS, falling back to an in-page Chrome POST.

    Full field list and error codes: `guide://lamoda/lamoda_card`.
    """
    log_event("lamoda_card.start", input=sku_or_url[:80])
    try:
        sku = _extract_sku(sku_or_url)
        if sku is None:
            raise_tool_error(
                BadRequestError(f"could not extract a SKU from {sku_or_url!r}; pass MP… or a lamoda.ru product URL")
            )
        product = await _graphql_card(sku, ctx)
        sizes_field = product.get("sizes")
        sizes_raw: list[Any] = sizes_field if isinstance(sizes_field, list) else []
        sizes = [
            LamodaSizeOut(size=s.get("size"), is_available=s.get("is_available"))
            for s in sizes_raw
            if isinstance(s, dict)
        ]
        result = LamodaCardResponse(
            sku=sku,
            title=product.get("name"),
            brand=product.get("brand_name"),
            price_rub=R.coerce_price(product.get("price_amount")),
            old_price_rub=R.coerce_price(R.first_present(product, "old_price_amount", "old_price")),
            is_available=product.get("is_available"),
            sizes=sizes,
            url=f"{SITE_BASE}/p/{sku.lower()}/",
            tier_used=product.get("_tier_used", "graphql"),
        )
        card = result.model_dump(by_alias=True, exclude={"meta", "sizes"})
        attached = R.attach_meta(card, R.validate_offer(card), source="lamoda_card")
        result.meta = MetaOut(**attached["_meta"])
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("lamoda_card.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"lamoda_card failed: {exc}")))


# CLI-only drift canary: ``marketplace-mcp doctor`` imports and calls lamoda_selfcheck()
# directly. It is deliberately NOT registered as an MCP tool — selfchecks are
# operator diagnostics, and their input/output schemas would be billed in every
# client request.
async def lamoda_selfcheck(ctx: Context | None = None) -> LamodaSelfcheckResponse:
    """Structural drift canary for Lamoda (tri-state). Probes the GraphQL card
    path (HTTPS with CDP fallback) and the CDP search path.

    GraphQL down is inconclusive for the card check; CDP down / a redirect loop
    is inconclusive for the search check. Only a reached payload that fails its
    parse smoke is drift.

    ## Return Format

    LamodaSelfcheckResponse: {status, healthy, connector, checks, ...}.

    ## Error Format

    Raises ToolError (TransportDownError) ONLY on an unexpected internal bug
    that prevents the canary from producing any verdict. Transport/block
    failures of individual sub-checks map to inconclusive entries, not errors.
    """
    log_event("lamoda_selfcheck.start")
    try:
        result = await _lamoda_selfcheck_impl(ctx)
        log_event("lamoda_selfcheck.done", status=result.status)
        return result
    except ToolError:
        raise
    except Exception as exc:
        log_event("lamoda_selfcheck.error", error=_redact(str(exc)), exc_type=type(exc).__name__)
        raise_tool_error(TransportDownError(_redact(f"lamoda_selfcheck failed: {exc}")))


async def _lamoda_selfcheck_impl(ctx: Context | None) -> LamodaSelfcheckResponse:
    checks: dict[str, dict] = {}

    # GraphQL tier: a 502/403 here means the endpoint moved or the wall grew.
    try:
        async with asyncio.timeout(60):
            await _graphql_card("MP002XM1RMM3", ctx)
        checks["card_graphql"] = R.selfcheck_entry(
            "healthy", baseline="graphql-products-v2", notes=["SKU enrichment answered"]
        )
    except ToolError as exc:
        state = "drift" if "ParserDrift" in type(exc).__name__ else "inconclusive"
        reason = "parse_smoke_failed" if state == "drift" else "transport_down"
        checks["card_graphql"] = R.selfcheck_entry(
            state, baseline="graphql-products-v2", reason=reason, notes=[str(exc)[:160]]
        )
    except Exception as exc:
        checks["card_graphql"] = R.selfcheck_entry(
            "inconclusive", baseline="graphql-products-v2", reason="transport_down", notes=[f"{type(exc).__name__}"]
        )

    # CDP tier: search tile extraction.
    baseline = "cdp-search-shape-v1"
    try:
        async with asyncio.timeout(90):
            payload = await _cdp_render_search("кроссовки", ctx)
        if _anti_bot_challenge(payload):
            checks["search"] = R.selfcheck_entry(
                "inconclusive", baseline=baseline, reason="blocked", notes=["anti-bot challenge in rendered page"]
            )
        else:
            items_raw = [*payload.get("items", [])] if isinstance(payload.get("items"), list) else []
            if items_raw:
                # Tiles extract — now ask the second question: did the SHAPE move?
                # The registry was measured on the captured page (2026-08-07); a
                # live payload that loses a parser-critical key family is
                # structural drift even while tiles still come back.
                live_signature = R.shape_signature(payload)
                drift = R.diff_keys(SEARCH_SHAPE_REFERENCE, live_signature)
                missing = missing_required_families(live_signature)
                if missing:
                    checks["search"] = R.selfcheck_entry(
                        "drift",
                        baseline=baseline,
                        reason="shape_drift",
                        notes=[
                            f"{len(items_raw)} tiles extracted",
                            "required key families missing: " + "; ".join(", ".join(family) for family in missing),
                        ],
                        shape_missing=drift["missing"],
                        shape_added=drift["added"],
                    )
                else:
                    notes = [f"{len(items_raw)} tiles extracted", "shape matches the captured reference"]
                    if drift["added"]:
                        notes.append(f"{len(drift['added'])} new paths vs baseline (informational)")
                    checks["search"] = R.selfcheck_entry(
                        "healthy", baseline=baseline, notes=notes, shape_added=drift["added"]
                    )
            else:
                checks["search"] = R.selfcheck_entry(
                    "drift", baseline=baseline, reason="parse_smoke_failed", notes=["zero SKUs"]
                )
    except ToolError as exc:
        checks["search"] = R.selfcheck_entry(
            "inconclusive", baseline=baseline, reason="transport_down", notes=[str(exc)[:160]]
        )
    except Exception as exc:
        checks["search"] = R.selfcheck_entry(
            "inconclusive", baseline=baseline, reason="transport_down", notes=[f"{type(exc).__name__}"]
        )

    result_dict = R.selfcheck_result(
        "lamoda",
        checks,
        required=("card_graphql", "search"),
        server_version=SERVER_VERSION,
        server_started_at=SERVER_STARTED_AT,
        process_id=None,
    )
    return LamodaSelfcheckResponse(**result_dict)


# Advertised output schemas are the dominant constant cost of an MCP mount:
# replace the full Pydantic tree with top-level field names (~64 % fewer
# wire tokens on the unified server).
apply_compact_output_schemas(mcp)

# The reference half of every tool description is served as an MCP resource
# (guide://<source>/<tool>) and the error taxonomy as marketplace://errors, so
# the agent pays for them when it reads them instead of on every request.
register_reference_resources(mcp)
